import { Component } from '@angular/core';
import { FormControl ,FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Reactiveform';
  amount = 104000
  name = 'cholamandalam finance and investment company'
  receiptDetails = [
    {
      items: [
        {
          receiptNo: "TEMPPTMB4009",
          mobileNo: "9465710425",
          amountPaid: 200000,
          modeOfPayment: "ONLINE_PAYMENT",
          receiptDateTime: "2020-03-30T12:21:41.360Z",
          receiptEnteredTime: "2020-03-30T12:21:41.360Z",
          isCancelled: false,
          instrumentDetail: { remarks: null },
          workflow: []
        },
        {
          receiptNo: "TEMPPTMB4008",
          mobileNo: "9465710425",
          amountPaid: 200000,
          modeOfPayment: "ONLINE_PAYMENT",
          receiptDateTime: "2020-03-30T12:15:48.753Z",
          receiptEnteredTime: "2020-03-30T12:15:48.753Z",
          isCancelled: false,
          instrumentDetail: { remarks: null },
          workflow: []
        },
        {
          receiptNo: "TEMPPTMB4004",
          mobileNo: "9465710425",
          amountPaid: 200000,
          modeOfPayment: "ONLINE_PAYMENT",
          receiptDateTime: "2020-03-30T12:09:54.268Z",
          receiptEnteredTime: "2020-03-30T12:09:54.268Z",
          isCancelled: false,
          instrumentDetail: { remarks: null },
          workflow: []
        },
        {
          receiptNo: "TEMPPTMB4003",
          mobileNo: "9465710425",
          amountPaid: 200000,
          modeOfPayment: "ONLINE_PAYMENT",
          receiptDateTime: "2020-03-30T12:08:10.769Z",
          receiptEnteredTime: "2020-03-30T12:08:10.769Z",
          isCancelled: false,
          instrumentDetail: { remarks: null },
          workflow: []
        },
        {
          receiptNo: "B10321025048",
          mobileNo: "9915553826",
          amountPaid: 255000,
          modeOfPayment: "RTGS",
          receiptDateTime: "2020-02-29T16:15:38.457Z",
          receiptEnteredTime: "2020-02-29T16:15:38.457Z",
          isCancelled: true,
          instrumentDetail: { status: "PENDING", remarks: null },
          workflow: [
            {
              workDoneBy: "CB00997",
              workDoneDate: "2020-02-29T16:15:38.860Z",
              workStatus: "INITIATED",
              requestType: "RTGS",
              comments: "UTR Number is not found",
              levelCode: "A0",
              assignedTo: ["B327", "G434", "V979", "R1517", "CP00163"],
              ImageRef: { imagePathReferences: [] }
            },
            {
              ImageRef: { imagePathReferences: [] },
              assignedTo: [],
              requestType: "RTGS",
              levelCode: "",
              workStatus: "REJECTED",
              comments:
                "Credit not found for the said UTR no & Amt , kindly share customer bank statement and Memo copy to verify.",
              workDoneDate: "2020-03-01T13:45:40.074Z",
              workDoneBy: "B327"
            }
          ]
        },
        {
          receiptNo: "T10400152595",
          mobileNo: "7814287806",
          amountPaid: 9620,
          modeOfPayment: "CASH",
          receiptDateTime: "2019-12-31T08:58:23.851Z",
          receiptEnteredTime: "2019-12-31T08:58:23.851Z",
          isCancelled: false,
          instrumentDetail: { status: "CLEARED", remarks: null },
          workflow: []
        },
        {
          receiptNo: "T10400152488",
          mobileNo: "7814287806",
          amountPaid: 9620,
          modeOfPayment: "CASH",
          receiptDateTime: "2019-11-29T04:56:38.703Z",
          receiptEnteredTime: "2019-11-29T04:56:38.703Z",
          isCancelled: false,
          instrumentDetail: { status: "CLEARED", remarks: null },
          workflow: []
        },
        {
          receiptNo: "T10400152393",
          mobileNo: "7814287806",
          amountPaid: 9620,
          modeOfPayment: "CASH",
          receiptDateTime: "2019-10-29T10:38:33.697Z",
          receiptEnteredTime: "2019-10-29T10:38:33.697Z",
          isCancelled: false,
          instrumentDetail: { status: "CLEARED", remarks: null },
          workflow: []
        },
        {
          receiptNo: "T10400152326",
          mobileNo: "7814287806",
          amountPaid: 9620,
          modeOfPayment: "CASH",
          receiptDateTime: "2019-09-30T12:49:52.997Z",
          receiptEnteredTime: "2019-09-30T12:49:52.997Z",
          isCancelled: false,
          instrumentDetail: { status: "CLEARED", remarks: null },
          workflow: []
        },
        {
          receiptNo: "T10400152231",
          mobileNo: "7814287806",
          amountPaid: 9620,
          modeOfPayment: "CASH",
          receiptDateTime: "2019-08-28T04:02:53.601Z",
          receiptEnteredTime: "2019-08-28T04:02:53.601Z",
          isCancelled: false,
          instrumentDetail: { status: "CLEARED", remarks: null },
          workflow: []
        }
      ]
    }
  ];
  receiptDeta: ({ receiptNo: string; mobileNo: string; amountPaid: number; modeOfPayment: string; receiptDateTime: string; receiptEnteredTime: string; isCancelled: boolean; instrumentDetail: { remarks: any; status?: undefined; }; workflow: any[]; } | {})[];

  classtoapply = 'class-fail class-special';
  registerform = new FormGroup({
    name : new FormControl(''),
    phone : new FormControl(''),
    email : new FormControl(''),
    password : new FormControl(''),
  });
 
  onSubmit(){
    console.log(this.registerform.value);
    
  }

  ngOnInit(){
    // this.receiptDeta = this.receiptDetails[0].items;
    this.receiptDeta = this.receiptDetails[0].items.filter((item) => {
      return item.receiptNo != "TEMP";
    })
  }

   

}
