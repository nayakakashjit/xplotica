<!doctype html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
   
    <title>TripTracs Transport management application - Xplotica IT Solution</title>
    <meta name="title" content="TripTracs Transport management application - Xplotica IT Solution"/>
    <meta name="description" content="TripTracs is a transportation management application designed specifically for daily trip tracking and making entire process easy. "/>
    <meta name= "keywords" content= "Transportation Management System" />
    <meta name= "keywords" content= "cab management system,auto management system,bus management system,school bus management system,logistics and transportation,logistics management,logistics software,employee transport management system,employee transportation services,employee transportation,transport management software India,transport management technology,employee transportation services in Bangalore,employee transport management,employee transportation solution,employee transportation services in Hyderabad,transport automation system,transportation management solutions,student transport management system,student transportation services,student transportation,student transport management,student transportation solution,student transportation services in Hyderabad" />
    
    
    
    <!-- FAVICON AND APPLE TOUCH  --> 
    <link rel="shortcut icon" href="favicon-180x180.png">  
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="favicon-180x180.png">
    
    <!-- FONTS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,300italic,300,500,500italic,700,700italic">
    
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="property/bootstrap/css/bootstrap.min.css"> 
    
    <!-- MT ICONS FONT -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="property/fonts/mt-icons/mt-icons.css">
    
    <!-- FANCYBOX -->
    <link rel="stylesheet" href="property/plugins/fancybox/jquery.fancybox.css">
	
	<!-- REVOLUTION SLIDER -->
    <link rel="stylesheet" href="property/plugins/revolutionslider/css/settings.css">
    
    <!-- OWL Carousel -->
    <link rel="stylesheet" href="property/plugins/owl-carousel/owl.carousel.css">
	<link rel="stylesheet" href="property/plugins/owl-carousel/owl.transitions.css">
	
	<!-- YOUTUBE PLAYER -->
    <link rel="stylesheet" href="property/plugins/ytplayer/css/jquery.mb.YTPlayer.min.css">
    
    <!-- ANIMATIONS -->
    <link rel="stylesheet" href="property/plugins/animations/animate.min.css">
    
    <!-- CUSTOM & PAGES STYLE -->
    <link rel="stylesheet" href="property/css/custom.css">
    <link rel="stylesheet" href="property/css/pages-style.css">
    
    <!-- STYLE SWITCHER -->
  <link rel="stylesheet" href="property/plugins/style-switcher/style-switcher.css">
    
    <!-- ALTERNATIVE STYLES -->
    <link rel="stylesheet" href="#" data-style="styles">
    

</head>
    <style>      
        input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    -moz-appearance:textfield;
}

a {
  text-decoration: none;
}
    </style>

<body>

	<div id="page-wrapper">
        
		<!-- HEADER -->
		<header>	
			
			<div id="header-top">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-8">
						
							<div class="widget widget-contact">
								
								<ul>
									<li>    
										<i class="mt-icon-telephone1"></i>
										<span class="hidden-xs" style="color: #fff;" style="text-decoration:none">+91 8867700428</span>
										<a class="visible-xs-inline" href="tel:+91 8867700428" style="text-decoration:none">+91 8867700428</a>
									</li>
									<li>
										<i class="mt-icon-mail"></i>
										<a href="#" style="text-decoration: none;">contact@xplotica.com</a>
									</li>
								</ul>
								
							</div><!-- widget-contact -->
							
						</div><!-- col -->
						<div class="col-sm-4">
						<div class="widget widget-contact">
								
								<ul style="text-align: right;margin-right: 3%;">
									<li>
									        <i class="mt-icon-telephone1"></i>
										<a href="support-xplotica.php">Support</a>
									</li>
									<li>
										<i class="fa fa-user" aria-hidden="true"></i>
										<a href="partner-xplotica.php">Partner</a>
									</li>
								
                                    <li>
										<i class="fa fa-rss" aria-hidden="true"></i>
										<a target="_blank" href="http://xplotica.com/blog">Blog</a>
									</li>
								</ul>
								
							</div>
							
							<!--<div class="widget widget-social">
												
								<div class="social-media">
								   <a class="facebook" href="#"><i class="mt-icon-facebook"></i></a>
									<a class="twitter" href="#"><i class="mt-icon-twitter"></i></a>
									<a class="google" href="#"><i class="mt-icon-google-plus"></i></a>
									<a class="pinterest" href="#"><i class="mt-icon-pinterest"></i></a>
									<a class="youtube" href="#"><i class="mt-icon-youtube-play"></i></a>                                    
								</div>
								
							</div>--><!-- widget-social -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->  
				
			</div><!-- header-top -->
			
			<div id="header">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							
							<!-- LOGO -->
							<div id="logo" style="margin-bottom: 3px;margin-top:3px;">
								<a href="index.php">
									<img src="property/images/logo xplotica.png" alt="">
								</a>
							</div><!-- logo -->
							
						</div><!-- col -->
						<div class="col-sm-10">
							
							<!-- MENU --> 
							<nav>
							
								<a id="mobile-menu-button" href="#"><i class="mt-icon-menu"></i></a>
												 
								<ul class="menu clearfix" id="menu">
									<li class="active">
										<a href="index.php" id="pd"><i class="mt-icon-home" style="font-weight:700;font-size: 16px;"></i></a>
									</li>
									<li>
										<a href="digi-edu.php" id="pd">Digiedu</a>
										
									</li>
									<!--<li class="dropdown">
												<a href="#" id="pd">Products</a>
												<ul>
													<li><a href="#">Trywis</a></li>
													<li><a href="#">Digiedu</a></li>
													<li><a href="#">Salon search</a></li>
													<li><a href="#">Pharmaceutical</a></li>
													<li><a href="#">Transportation</a></li>
												</ul>
											</li>-->
									<li>
										<a href="phamarc.php" id="pd">PHAMARC</a>
										
									</li>
									<li>
										<a href="transportation.php" id="pd">TRIPTRACS</a>
										
									</li>
									<!--<li class="dropdown">
										<a href="salon_search.php" id="pd">Salon</a>
										
									</li>-->
									
									<li class="dropdown">
												<a href="#" id="pd">INDUSTRY</a>
												<ul>
													
													<!--<li><a href="salon_search_industry.php">Salon</a></li> -->	
													<li><a href="Education-industry.php">Education</a></li>
													<li><a href="Pharmaceutical-industry.php">Pharmaceutical</a></li>
													<li><a href="transportation-industry.php">Transportation</a></li>
													
												</ul>
											</li>
											<li>
										<a href="contact-us.php" id="pd">CONTACT US</a>
										
									</li>
									
								</ul>
							
							</nav>
						
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->    
						
			</div><!-- header -->
		
		</header><!-- HEADER -->


 <link rel="stylesheet" href="property/css/custom_modal.css">
<style>
    .horizontal-tabs.big-tabs .nav-tabs > li > a {
    padding: 24px 76px;
}

</style>
 <style>
.top{margin-top: 4%;}
.modal-style{border-radius: 0px;}
..input-group-addon {
               color: #009688 !important;
}
</style>
 <!-- CONTENT -->
        <div id="page-content">
            
            <div id="page-header">  
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            
                            <h4>WELCOME TO TRIPTRACS</h4>
                            
                        </div><!-- col -->
                    </div><!-- row -->
                </div><!-- container -->    
            </div><!-- page-header -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>About TripTracs</h3>
							<!--<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem.</p>-->
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
            <div class="container">
                <p>
               TripTracs is a corporate cab management application designed specifically for daily trip tracking and making the entire process easy. It is designed to handle multiple clients diverse on geographical area and quality of the clients. With enhanced database design to create the desired report and multiple commuters tracking it is a groundbreaking application for corporate cab facilitators. The Application is having Its Employee interface designed in Android and IOS while Driver module in the Android. It is a user-friendly lightweight android application.
                </p>
            </div>
			<br>
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class=" horizontal-tabs big-tabs">
						
							<ul class="nav nav-tabs">
								<li class="active"><a href="#tab-3-1" data-toggle="tab"><!--<i class="mt-icon-films">--></i>Admin Module</a></li>
								<li><a href="#tab-3-2" data-toggle="tab"><!--<i class="mt-icon-code"></i>-->Cab Manager</a></li>
								<li><a href="#tab-3-3" data-toggle="tab"><!--<i class="mt-icon-stars"></i>-->Office Admin </a></li>
								<li><a href="#tab-3-4" data-toggle="tab"><!--<i class="mt-icon-smartphone3"></i>-->User</a></li>
                                <li><a href="#tab-3-5" data-toggle="tab"><!--<i class="mt-icon-smartphone3"></i>-->Driver</a></li>
							</ul>                                            
						
							 <div class="tab-content">
								<div class="tab-pane fade in active" id="tab-3-1">
									
									<div class="row">
										<div class="col-sm-6">
											
											<p><img src="images/triptrac/Admin.jpg" alt=""></p>
											
										</div><!-- col -->
										<div class="col-sm-6">
											
											<h4>Admin Module. </h4>
											
											<br>
											
											<p>The Admin module is Master module for the Application for adding Cab manager, adding client details. The module is designed completely report-centric and can be enhanced for the desired reports. </p>
											
										<!--	<a class="btn btn-default" href="#">Learn more</a>-->
											
										</div><!-- col -->
									</div><!-- row -->
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-3-2">
									
									<div class="row">
										<div class="col-sm-6">
											
											<p><img src="images/triptrac/cab%20manager.jpg" alt=""></p>
											
										</div><!-- col -->
										<div class="col-sm-6">
											
											<h4>Cab Manager </h4>
											
											<br>
											
											<p>Cab manager will do the route creation, Driver and cab registration, Cab allocation to employee, Adhoc allocation, Guest cab allocation </p>
											
											<!--<a class="btn btn-default" href="#">Learn more</a>-->
											
										</div><!-- col -->
									</div><!-- row -->
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-3-3">
									
									<div class="row">
										<div class="col-sm-6">
											
											<p><img src="images/triptrac/office%20manager.jpg" alt=""></p>
											
										</div><!-- col -->
										<div class="col-sm-6">
											
											<h4>Office Admin</h4>
											
											<br>
											
											<p>The office admin is none other the employee of the client it has registration process they can rise the guest request for the office guest that will be generated through the admin panel, they the report of the driver details, cab details, daily trip allocation etc.</p>
											
											<!--<a class="btn btn-default" href="#">Learn more</a>-->
											
										</div><!-- col -->
									</div><!-- row -->
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-3-4">
									
									<div class="row">
										<div class="col-sm-6">
											
											<p><img src="images/triptrac/user.jpg" alt=""></p>
											
										</div><!-- col -->
										<div class="col-sm-6">
											
											<h4>User</h4>
											
											<br>
											
											<p>Easy to use and feature rich user application has been designed for, the user to request for the cab from his Profile, get the Cab Details,
											Driver Details, travel Route, History, Notification Request for the change in schedule GPS tracking to track the driver location and arrival
											time Driver and Cab detail Escort Profile with Photo for the safety measures.</p>
											
											<!--<a class="btn btn-default" href="#">Learn more</a>-->
											
										</div><!-- col -->
									</div><!-- row -->
										
								</div><!-- tab-pane -->
                                 <div class="tab-pane fade" id="tab-3-5">
									
									<div class="row">
										<div class="col-sm-6">
											
											<p><img src="images/triptrac/Driver.jpg" alt=""></p>
											
										</div><!-- col -->
										<div class="col-sm-6">
											
											<h4>Driver</h4>
											
											<br>
											
											<p>GPS Tracking for the driver, cloud calling, multiple employee tracking and Google map integration make the driver work easy to handle. 
											Saving all the trip and route record, generation of Trip sheet after completion are extra feature for the operational activity.</p>
											
											<!--<a class="btn btn-default" href="#">Learn more</a>-->
											
										</div><!-- col -->
									</div><!-- row -->
										
								</div><!-- tab-pane -->
							</div><!-- tab-content -->
						
						</div><!-- horizontal-tabs -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>Important Features of TripTracs</h3>
							<!--<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem.</p>-->
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-72">
						
						<div class="squares-tabs">
						
							<ul class="nav nav-tabs">
								<li class="active"><a href="#tab-7-7" data-toggle="tab">
                                    <img src="images/icons/Safe%20Rides.png" alt=""></a></li>
									
									<li><a href="#tab-7-3" data-toggle="tab"><img src="images/icons/Security,%20%20Tracking.png" alt=""></a></li>
									
                                
								<li><a href="#tab-7-2" data-toggle="tab"><img src="images/icons/User%20Friendly.png" alt=""></a></li>
                                
                                
								<li><a href="#tab-7-4" data-toggle="tab"><img src="images/icons/SOS%20Alert.png" alt=""></a></li>
                                
								<li><a href="#tab-7-5" data-toggle="tab"><img src="images/icons/Reports.png" alt=""></a></li>
                                
								<li><a href="#tab-7-6" data-toggle="tab"><img src="images/icons/Light%20weight.png" alt=""></a></li>
							</ul>                                            
						
							 <div class="tab-content">
								<div class="tab-pane fade in active" id="tab-7-7">
									
									<h4>Safe Rides</h4>
									
									<br>
									
									<p>Verified drivers, an SOS button, and live ride tracking are some of the features of TripTracs to keep you safe and secure.</p>
									
									<!--<a class="btn btn-default" href="#">Learn more</a>-->
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-7-2">
									
									<h4>Security</h4>
									
									<br>
									
									<p>Cloud calling facility for driver and employee with the SOS alert, Real-time GPS tracking, and escort creation are added security features for the employees.</p>
									
									<!--<a class="btn btn-default" href="#">Learn more</a>-->
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-7-3">
									
									<h4>Tracking</h4>
									
									<br>
									
									<p>The real time GPS will update itself to know the location of the cab and employee. All the data will be saved and display as a report in the Admin panel .Route map will be shared both to the employees and the driver from the client location to the drop point.</p>
									</div>
									<!--<a class="btn btn-default" href="#">Learn more</a>--
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-7-4">
									
									<h4>SOS Alert</h4>
									
									<br>
									
									<p>SOS Alert will provide an extra umbrella of safety. A user can save up to three no. for the Emergency contact.</p>
									
									<!--<a class="btn btn-default" href="#">Learn more</a>-->
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-7-5">
									
									<h4>Reports</h4>
									
									<br>
									
									<p>The robust database is designed to create the desired report according to the client requirement.</p>
									
									<!--<a class="btn btn-default" href="#">Learn more</a>-->
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-7-6">
									
									<h4>Light weight and User friendly</h4>
									
									<br>
									
									<p>The User Experience team has designed the application flow keeping it user-centric and we keep improvising it according to user feedback and technology changes.</p>
									
									<!--<a class="btn btn-default" href="#">Learn more</a>-->
										
								</div><!-- tab-pane -->
							</div><!-- tab-content -->
						
						</div><!-- horizontal-tabs -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
            <div class="container">
						<div class="row">
							<div class="col-sm-8">
                               
							</div><!-- col -->
                                                  <div class="col-sm-2 text-right">
							
								<!--<a class="btn btn-default" data-toggle="modal" data-target="#myModal-2">Book your Demo</a>-->
                                <a href="contact-us.php" class="btn btn-default">Book your Demo</a>
								
							</div>
							<div class="col-sm-2 text-right">
						
								<a class="btn btn-default" href="http://triptracs.com/" target="_blank">More Details</a>
								
							</div><!-- col -->
						</div><!-- row -->
					</div>
            
        </div><!-- PAGE CONTENT -->
<div class="modal fade" id="myModal-2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel-2">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content" style="margin-top: 28%;">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel-2">Enter your Details</h4>
                </div>

                <div class="modal-body">
                    <form id="myform" action="mailcareetrip.php" method="POST">
 
					<div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-user" style="color:#3badad"></i></span>
						<input id="Text" type="text" class="form-control modal-style" name="name" placeholder="Name"  required="">
					</div>
					<div class="input-group top">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-phone" style="color:#3badad"></i></span>
						<input id="Text" type="number" class="form-control modal-style" name="phone" placeholder="Phone number" pattern="^\d{10}$"  required="">
					</div>
							
					<div class="input-group top">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope" style="color:#3badad"></i></span>
						<input id="email" type="text" class="form-control modal-style" name="email" placeholder="Email" required="">
					</div>
					<div class="form-group top">
					  <textarea class="form-control modal-style" rows="4" id="comment" placeholder="Message" name="message" required=""></textarea>
					</div>
					
					
                        <center>
                            <button class="btn btn-success top" type="submit" id="btn_submit" style="background-color: #fe5e3e!important">Submit</button>
                        </center>
                    </form>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <!--<button type="button" class="btn btn-dialog">Ok</button>-->
                </div>
            </div>
            <!-- modal-content -->
        </div>
        <!-- modal-dialog -->
    </div>
<?php include("footer.php"); ?>