<!doctype html>
<html>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
   
    <title>Contact us - Xplotica IT Solution</title>
    <meta name="title" content="Contact us - Xplotica IT Solution"/>
    <meta name="description" content="Contact us for Management System App | Quote or any Queries"/>
    <meta name= "keywords" content= "Contact Xplotica IT Solutions Pvt. Ltd.," />
   <meta name= "keywords" content= "About Xplotica IT Solutions Pvt. Ltd.,,Xplotica IT Solutions Pvt. Ltd.,,Xplotica,Xplotica IT Solutions,School Management System,Pharmaceutical product management Application,Transportation Management System,School Management System Application,Pharmaceutical Product Management System,Transportation Management System" />
    
    <!-- FAVICON AND APPLE TOUCH  --> 
    <link rel="shortcut icon" href="favicon-180x180.png">  
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="favicon-180x180.png">
    
    <!-- FONTS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,300italic,300,500,500italic,700,700italic">
    
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="property/bootstrap/css/bootstrap.min.css"> 
    
    <!-- MT ICONS FONT -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="property/fonts/mt-icons/mt-icons.css">
    
    <!-- FANCYBOX -->
    <link rel="stylesheet" href="property/plugins/fancybox/jquery.fancybox.css">
	
	<!-- REVOLUTION SLIDER -->
    <link rel="stylesheet" href="property/plugins/revolutionslider/css/settings.css">
    
    <!-- OWL Carousel -->
    <link rel="stylesheet" href="property/plugins/owl-carousel/owl.carousel.css">
	<link rel="stylesheet" href="property/plugins/owl-carousel/owl.transitions.css">
	
	<!-- YOUTUBE PLAYER -->
    <link rel="stylesheet" href="property/plugins/ytplayer/css/jquery.mb.YTPlayer.min.css">
    
    <!-- ANIMATIONS -->
    <link rel="stylesheet" href="property/plugins/animations/animate.min.css">
    
    <!-- CUSTOM & PAGES STYLE -->
    <link rel="stylesheet" href="property/css/custom.css">
    <link rel="stylesheet" href="property/css/pages-style.css">
    
    <!-- STYLE SWITCHER -->
  <link rel="stylesheet" href="property/plugins/style-switcher/style-switcher.css">
    
    <!-- ALTERNATIVE STYLES -->
    <link rel="stylesheet" href="#" data-style="styles">
    
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>

</head>
    <style>      
        input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    -moz-appearance:textfield;
}

a {
  text-decoration: none;
}
        .error{
            color: #ff662e;
        }
        
.btn.disabled, .btn[disabled], fieldset[disabled] .btn {
    cursor: not-allowed;
    filter: alpha(opacity=65);
    -webkit-box-shadow: none;
    box-shadow: none;
    opacity: .65;
     border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
}
        
    </style>

<body ng-app="">

	<div id="page-wrapper">
        
		<!-- HEADER -->
		<header>	
			
			<div id="header-top">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-8">
						
							<div class="widget widget-contact">
								
								<ul>
									<li>    
										<i class="mt-icon-telephone1"></i>
										<span class="hidden-xs" style="color: #fff;" style="text-decoration:none">+91 8867700428</span>
										<a class="visible-xs-inline" href="tel:+91 8867700428" style="text-decoration:none">+91 8867700428</a>
									</li>
									<li>
										<i class="mt-icon-mail"></i>
										<a href="#" style="text-decoration: none;">contact@xplotica.com</a>
									</li>
								</ul>
								
							</div><!-- widget-contact -->
							
						</div><!-- col -->
						<div class="col-sm-4">
						<div class="widget widget-contact">
								
								<ul style="text-align: right;margin-right: 3%;">
									<li>
									        <i class="mt-icon-telephone1"></i>
										<a href="support-xplotica.php">Support</a>
									</li>
									<li>
										<i class="fa fa-user" aria-hidden="true"></i>
										<a href="partner-xplotica.php">Partner</a>
									</li>
								
                                    <li>
										<i class="fa fa-rss" aria-hidden="true"></i>
										<a target="_blank" href="http://xplotica.com/blog">Blog</a>
									</li>
								</ul>
								
							</div>
							
							<!--<div class="widget widget-social">
												
								<div class="social-media">
								   <a class="facebook" href="#"><i class="mt-icon-facebook"></i></a>
									<a class="twitter" href="#"><i class="mt-icon-twitter"></i></a>
									<a class="google" href="#"><i class="mt-icon-google-plus"></i></a>
									<a class="pinterest" href="#"><i class="mt-icon-pinterest"></i></a>
									<a class="youtube" href="#"><i class="mt-icon-youtube-play"></i></a>                                    
								</div>
								
							</div>--><!-- widget-social -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->  
				
			</div><!-- header-top -->
			
			<div id="header">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							
							<!-- LOGO -->
							<div id="logo" style="margin-bottom: 3px;margin-top:3px;">
								<a href="index.php">
									<img src="property/images/logo xplotica.png" alt="">
								</a>
							</div><!-- logo -->
							
						</div><!-- col -->
						<div class="col-sm-10">
							
							<!-- MENU --> 
							<nav>
							
								<a id="mobile-menu-button" href="#"><i class="mt-icon-menu"></i></a>
												 
								<ul class="menu clearfix" id="menu">
									<li class="active">
										<a href="index.php" id="pd"><i class="mt-icon-home" style="font-weight:700;font-size: 16px;"></i></a>
									</li>
									<li>
										<a href="digi-edu.php" id="pd">Digiedu</a>
										
									</li>
									<!--<li class="dropdown">
												<a href="#" id="pd">Products</a>
												<ul>
													<li><a href="#">Trywis</a></li>
													<li><a href="#">Digiedu</a></li>
													<li><a href="#">Salon search</a></li>
													<li><a href="#">Pharmaceutical</a></li>
													<li><a href="#">Transportation</a></li>
												</ul>
											</li>-->
									<li>
										<a href="phamarc.php" id="pd">PHAMARC</a>
										
									</li>
									<li>
										<a href="transportation.php" id="pd">TRIPTRACS</a>
										
									</li>
									<!--<li class="dropdown">
										<a href="salon_search.php" id="pd">Salon</a>
										
									</li>-->
									
									<li class="dropdown">
												<a href="#" id="pd">INDUSTRY</a>
												<ul>
													
													<!--<li><a href="salon_search_industry.php">Salon</a></li> -->	
													<li><a href="Education-industry.php">Education</a></li>
													<li><a href="Pharmaceutical-industry.php">Pharmaceutical</a></li>
													<li><a href="transportation-industry.php">Transportation</a></li>
													
												</ul>
											</li>
											<li>
										<a href="contact-us.php" id="pd">CONTACT US</a>
										
									</li>
									
								</ul>
							
							</nav>
						
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->    
						
			</div><!-- header -->
		
		</header><!-- HEADER -->

<!-- CONTENT -->
        <div id="page-content">
            
            <div id="page-header">  
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            
                            <h4>Contact</h4>
                            
                        </div><!-- col -->
                    </div><!-- row -->
                </div><!-- container -->    
            </div><!-- page-header -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>Get in touch</h3>
							<p>Please send us an e-mail by filling out the form below, we will quickly get back to you (usually within 24 hours). We would love to discuss any projects you have in mind.</p>
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			 </div><!-- container -->
			
			 <div class="container">
				<div class="row">
					<div class="col-sm-8">
					
						<h6 class="text-uppercase">Contact us</h6>
						
						<form name="sentMessage" action="contact-mailfunction.php" method="post">
                            <fieldset>
                                
                                <div id="alert-area"></div>
                                
                                <div class="row">
									<div class="col-sm-6">
										
<input class="col-xs-12" data-ng-model ="username" type="text" name="username" placeholder="Name" ng-minlength="3" ng-maxlength="15" required />
  <span class="error" ng-show="sentMessage.username.$dirty || sentMessage.username.$touched && sentMessage.username.$invalid">
                <span data-ng-show="sentMessage.username.$error.required">Please enter your name.</span>
                <div role="alert">
                    <span class="error" data-ng-show="sentMessage.username.$error.minlength">Too short!</span>
                    <span class="error" data-ng-show="sentMessage.username.$error.maxlength">Too long!</span>
                </div>
            </span>									
									</div>
								   <div class="col-sm-6">
										
<input class="col-xs-12" type="email" placeholder="E-mail" data-ng-model="email" name="email" required />
 <span class="error"  data-ng-show="sentMessage.email.$dirty || sentMessage.email.$touched && sentMessage.email.$invalid">
                <span data-ng-show="sentMessage.email.$error.required">Please enter your email.</span>
                <span data-ng-show="sentMessage.email.$error.email">Invalid email address.</span>
            </span>										
									</div>
								</div>
								
								 <div class="row">
								 <div class="col-sm-6">
										
<input class="col-xs-12" type="number" name="phonenumber" placeholder="Mobile number" data-ng-model="mobile" ng-maxlength="10" ng-pattern="/(7|8|9)\d{9}/" />
                <span class="error" data-ng-show="sentMessage.phonenumber.$dirty || sentMessage.phonenumber.$touched && sentMessage.phonenumber.$invalid">
                <span data-ng-show="sentMessage.phonenumber.$error.required">Please enter your mobile number.</span>
                <div role="alert">
                    <span class="error" data-ng-show="sentMessage.phonenumber.$error.pattern">Not a valid mobile number.</span>
                    <span class="error" data-ng-show="sentMessage.phonenumber.$error.maxlength">Too long!</span>
                </div>
            </span>
										
									</div><!-- col -->
									<div class="col-sm-6">
										
<input class="col-xs-12" data-ng-model="subject" type="text" name="subject" required="" placeholder="Subject">
 <span class="error" data-ng-show="sentMessage.subject.$dirty || sentMessage.subject.$touched && sentMessage.subject.$invalid">
                    <span class="error" data-ng-show="sentMessage.subject.$error.required">Please Enter Your Message.</span>
                   
                    </span>										
									</div><!-- col -->
									
								</div><!-- row -->
								
								

<textarea class="col-xs-12" data-ng-model="message" name="message" required="" rows="4" cols="25" placeholder="Message"></textarea>
                    <span class="error" data-ng-show="sentMessage.message.$dirty || sentMessage.message.$touched && sentMessage.message.$invalid">
                    <span class="error" data-ng-show="sentMessage.message.$error.required">Please Enter Your Message.</span>
                   
                    </span>
                            
                                
                            </fieldset>
                            
                                <input class="btn btn-default" data-ng-disabled="sentMessage.$invalid" id="submit" type="submit" name="submit" value="Submit">
                        </form>
						
					</div><!-- col -->
					<div class="col-sm-4">
						
						<div class="widget widget-contact">
															
							<h6 class="widget-title">Contact</h6>
							
							<ul>
								<li>
									<i class="mt-icon-map-marker1"></i>
									 #43,4th floor, Above Federal Bank, SGR Plaza,<br class="hidden-sm"> Old Airport Road, Marathahalli, Bangalore<br class="hidden-sm">
									Karnataka, 560037 
								</li>
								<li>    
									<i class="mt-icon-telephone1"></i>
									+91 8867700428
								</li>
								<li>    
									<i class="mt-icon-telephone1"></i>
									+91 8040964117
								</li>
								<li>
									<i class="mt-icon-mail"></i>
									<a href="mailto:contact@xplotica.com" style="color:#555">contact@xplotica.com</a>
								</li>
								<li>
									<i class="mt-icon-earth"></i>
									<a href="#" style="color:#555">www.xplotica.com</a>
								</li>
							</ul>
							
						</div><!-- widget-contact -->
						
						
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<!--<div class="map" data-zoom="15" data-address="Poplar Chase Lane Sandpoint, USA" data-address-details="<img src='assets/images/logo.png'>" style="margin-bottom:-70px;"></div>-->
	
        </div><!-- PAGE CONTENT -->
		
		<?php include("footer.php"); ?>