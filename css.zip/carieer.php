<!doctype html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    
    <title>Career - Xplotica IT Solution</title>
   <meta name="title" content="Career - Xplotica IT Solution"/>
    <meta name="description" content="Xplotica IT solutions Pvt LTD, #43,SGR Plaza, Above Federal Bank,Marathahalli,Bengaluru, Karnataka 560037; contact@xplotica.com. Xplotica © 2015."/>
    <meta name= "keywords" content= "Job opportunity in Bangalore" />
    <meta name= "keywords" content= "Apply for jobs,Job Application,jobs in banglore,jobs for developers,About Xplotica IT Solutions Pvt. Ltd.,,Xplotica,Xplotica IT Solutions,Xplotica IT Solutions Pvt. Ltd.,,School Management System,Pharmaceutical product management Application,Transportation Management System,School Management System Application,Pharmaceutical Product Management System,Transportation Management System" />
    
    <!-- FAVICON AND APPLE TOUCH  --> 
    <link rel="shortcut icon" href="favicon-180x180.png">  
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="favicon-180x180.png">
    
    <!-- FONTS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,300italic,300,500,500italic,700,700italic">
    
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="property/bootstrap/css/bootstrap.min.css"> 
    
    <!-- MT ICONS FONT -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="property/fonts/mt-icons/mt-icons.css">
    
    <!-- FANCYBOX -->
    <link rel="stylesheet" href="property/plugins/fancybox/jquery.fancybox.css">
	
	<!-- REVOLUTION SLIDER -->
    <link rel="stylesheet" href="property/plugins/revolutionslider/css/settings.css">
    
    <!-- OWL Carousel -->
    <link rel="stylesheet" href="property/plugins/owl-carousel/owl.carousel.css">
	<link rel="stylesheet" href="property/plugins/owl-carousel/owl.transitions.css">
	
	<!-- YOUTUBE PLAYER -->
    <link rel="stylesheet" href="property/plugins/ytplayer/css/jquery.mb.YTPlayer.min.css">
    
    <!-- ANIMATIONS -->
    <link rel="stylesheet" href="property/plugins/animations/animate.min.css">
    
    <!-- CUSTOM & PAGES STYLE -->
    <link rel="stylesheet" href="property/css/custom.css">
    <link rel="stylesheet" href="property/css/pages-style.css">
    
    <!-- STYLE SWITCHER -->
  <link rel="stylesheet" href="property/plugins/style-switcher/style-switcher.css">
    
    <!-- ALTERNATIVE STYLES -->
    <link rel="stylesheet" href="#" data-style="styles">
    

</head>
    <style>      
        input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    -moz-appearance:textfield;
}

a {
  text-decoration: none;
}
    </style>

<body>

	<div id="page-wrapper">
        
		<!-- HEADER -->
		<header>	
			
			<div id="header-top">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-8">
						
							<div class="widget widget-contact">
								
								<ul>
									<li>    
										<i class="mt-icon-telephone1"></i>
										<span class="hidden-xs" style="color: #fff;" style="text-decoration:none">+91 8867700428</span>
										<a class="visible-xs-inline" href="tel:+91 8867700428" style="text-decoration:none">+91 8867700428</a>
									</li>
									<li>
										<i class="mt-icon-mail"></i>
										<a href="#" style="text-decoration: none;">contact@xplotica.com</a>
									</li>
								</ul>
								
							</div><!-- widget-contact -->
							
						</div><!-- col -->
						<div class="col-sm-4">
						<div class="widget widget-contact">
								
								<ul style="text-align: right;margin-right: 3%;">
									<li>
									        <i class="mt-icon-telephone1"></i>
										<a href="support-xplotica.php">Support</a>
									</li>
									<li>
										<i class="fa fa-user" aria-hidden="true"></i>
										<a href="partner-xplotica.php">Partner</a>
									</li>
								
                                    <li>
										<i class="fa fa-rss" aria-hidden="true"></i>
										<a target="_blank" href="http://xplotica.com/blog">Blog</a>
									</li>
								</ul>
								
							</div>
							
							<!--<div class="widget widget-social">
												
								<div class="social-media">
								   <a class="facebook" href="#"><i class="mt-icon-facebook"></i></a>
									<a class="twitter" href="#"><i class="mt-icon-twitter"></i></a>
									<a class="google" href="#"><i class="mt-icon-google-plus"></i></a>
									<a class="pinterest" href="#"><i class="mt-icon-pinterest"></i></a>
									<a class="youtube" href="#"><i class="mt-icon-youtube-play"></i></a>                                    
								</div>
								
							</div>--><!-- widget-social -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->  
				
			</div><!-- header-top -->
			
			<div id="header">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							
							<!-- LOGO -->
							<div id="logo" style="margin-bottom: 3px;margin-top:3px;">
								<a href="index.php">
									<img src="property/images/logo xplotica.png" alt="">
								</a>
							</div><!-- logo -->
							
						</div><!-- col -->
						<div class="col-sm-10">
							
							<!-- MENU --> 
							<nav>
							
								<a id="mobile-menu-button" href="#"><i class="mt-icon-menu"></i></a>
												 
								<ul class="menu clearfix" id="menu">
									<li class="active">
										<a href="index.php" id="pd"><i class="mt-icon-home" style="font-weight:700;font-size: 16px;"></i></a>
									</li>
									<li>
										<a href="digi-edu.php" id="pd">Digiedu</a>
										
									</li>
									<!--<li class="dropdown">
												<a href="#" id="pd">Products</a>
												<ul>
													<li><a href="#">Trywis</a></li>
													<li><a href="#">Digiedu</a></li>
													<li><a href="#">Salon search</a></li>
													<li><a href="#">Pharmaceutical</a></li>
													<li><a href="#">Transportation</a></li>
												</ul>
											</li>-->
									<li>
										<a href="phamarc.php" id="pd">PHAMARC</a>
										
									</li>
									<li>
										<a href="transportation.php" id="pd">TRIPTRACS</a>
										
									</li>
									<!--<li class="dropdown">
										<a href="salon_search.php" id="pd">Salon</a>
										
									</li>-->
									
									<li class="dropdown">
												<a href="#" id="pd">INDUSTRY</a>
												<ul>
													
													<!--<li><a href="salon_search_industry.php">Salon</a></li> -->	
													<li><a href="Education-industry.php">Education</a></li>
													<li><a href="Pharmaceutical-industry.php">Pharmaceutical</a></li>
													<li><a href="transportation-industry.php">Transportation</a></li>
													
												</ul>
											</li>
											<li>
										<a href="contact-us.php" id="pd">CONTACT US</a>
										
									</li>
									
								</ul>
							
							</nav>
						
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->    
						
			</div><!-- header -->
		
		</header><!-- HEADER -->


<style>
.input {
    width: 100%;
    margin: 8px 0;
    box-sizing: border-box;
    border: 1px solid #0cadbe;
    padding: 7px 10px;
    -webkit-transition: 0.5s;
    transition: 0.5s;
    outline: none;
}
</style>
        <!-- xxxxxxxxxxxxxxxxx banner startxxxxxxxxxxxxxxxx-->
	 <div id="page-content">	
 <div class="container"> 
<img src="images/career/img.jpg" class="img-responsive" style="height:280px;width:1140px;" alt="phoenix grs">
</div>
<!-- xxxxxxxxxxxxxxxxx banner End  xxxxxxxxxxxxxxxx-->

 <!-- xxxxxxxxxxxxxxxxx Form start xxxxxxxxxxxxxxxx-->
 <div class="container"> 
<div class="row">
   <div class="col-md-8">
<!-- <div class="row"> -->

<form class="clearfix" id="contact-form" name="contact-form" method="post" action="post">
                            <fieldset>
                                
                                <div id="alert-area"></div>
                                
                                <div class="row">
									<div class="col-sm-6">
										
										<input class="col-xs-12" id="name" type="text" name="name" placeholder="name">
										
									</div><!-- col -->
									<div class="col-sm-6">
										
										<input class="col-xs-12" id="email" type="email" name="email" placeholder="e-mail">
										
									</div><!-- col -->
								</div><!-- row -->
								
								 <div class="row">
								 <div class="col-sm-6">
										
										<input class="col-xs-12" id="number" type="number" name="number" placeholder="Mobile number">
										
									</div><!-- col -->
									<div class="col-sm-6">
										
										<select>
										<option>Select Experience</option>
							<option>Experience</option>
							<option>Fresher</option>
							
						</select>
										
									</div><!-- col -->
									
								</div><!-- row -->
								<div class="row">
								 <div class="col-sm-6">
										
										
										
									</div><!-- col -->
									<div class="col-sm-6">
										
										<input class="col-xs-12" id="number" type="file" name="number" placeholder="Mobile number">
										
									</div><!-- col -->
									
								</div>
								
								

                                <textarea class="col-xs-12" id="message" name="message" rows="4" cols="25" placeholder="Residental Address"></textarea>
								<textarea class="col-xs-12" id="message" name="message" rows="4" cols="25" placeholder="Permanent  Address"></textarea>
                            
                                <input class="btn btn-default" id="submit" type="submit" name="submit" value="Submit">
                                
                            </fieldset>
                        </form>


<!-- </div> -->

</div>
  <div class="col-md-4"> 
<img src="images/career/checklist.jpg" class="img-responsive" style="margin-top:8%;" alt="phoenix grs">
</div>
</div>
</div>
</div>
 <!-- xxxxxxxxxxxxxxxxx Form End  xxxxxxxxxxxxxxxx-->
	<?php include("footer.php"); ?>
	
