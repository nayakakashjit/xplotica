 <div class="bannercontainer">
                <div class="banner">
                    <ul>
						<li data-transition="slotslide-horizontal" data-slotamount="50">
                            
                            <img src="images/index/revolution-slider/bg-slide-3.jpg" alt="">
							
							<div class="tp-caption title-big sft" data-x="center" data-y="85" data-speed="700" data-start="2700" data-easing="easeOutBack" style=" font-size: 36px;">	Exploring Technology .
							</div>
							
							<div class="tp-caption fade" data-x="center" data-hoffset="50" data-y="275" data-speed="700" data-start="1500" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s1.png" alt="">
							</div>
							
							<div class="tp-caption customin" data-customin="scaleX:0;scaleY:0;" data-x="center" data-y="155" data-speed="1200" data-start="2000" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/slide-3-image-2.png" alt="">
							</div>							
							
						</li>
                        <li data-transition="slotslide-horizontal" data-slotamount="50">
                            
                            <img src="images/index/revolution-slider/bg-slide-1.jpg" alt="">
							
							<div class="tp-caption sfb" data-x="355" data-y="325" data-speed="700" data-start="1500" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s2.png" alt="">
							</div>
							
							<div class="tp-caption sfb" data-x="540" data-y="305" data-speed="700" data-start="1700" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s3.png" alt="">
							</div>
							
							<div class="tp-caption sfb" data-x="720" data-y="285" data-speed="700" data-start="1900" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s4.png" alt="">
							</div>
							
							<div class="tp-caption sfb" data-x="595" data-y="170" data-speed="700" data-start="2300" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s5.png" alt="">
							</div>
							
				<div class="tp-caption title-small sfl" data-x="30" data-y="210" data-speed="700" data-start="2700" data-easing="easeOutBack">
                            	Welcome to Xplotica   
				</div>
							
							<div class="tp-caption text sfl" data-x="30" data-y="315" data-speed="700" data-start="3000" data-easing="easeOutBack">
                            	Welcome to Xplotica IT Solution is a web development company <br> established in Bangalore, India. <br> It has a long way building trustworthy customer <br> relationship by delivering quality and customer satisfaction.
							</div>
							
							<!--<div class="tp-caption sfb" data-x="30" data-y="430" data-speed="700" data-start="3500" data-easing="easeOutBack">
                            	<a class="btn btn-default" href="#">Learn more</a>
							</div>-->
							
							<div class="pattern"></div>
							
						</li>
						<li data-transition="slotslide-horizontal" data-slotamount="50">
                            
                            <img src="images/index/revolution-slider/bg-slide-2.jpg" alt="">
							
							<div class="tp-caption sfb" data-x="center" data-y="bottom" data-speed="700" data-start="1500" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s6.png" alt="">
							</div>
							
							<div class="tp-caption customin" data-customin="scaleX:1.2;scaleY:1.2;" data-x="0" data-y="230" data-speed="700" data-start="1800" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s7.png" alt="">
							</div>
							
							<div class="tp-caption customin" data-customin="scaleX:1.2;scaleY:1.2;" data-x="950" data-y="485" data-speed="700" data-start="2000" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s8.png" alt="">
							</div>
							
							<div class="tp-caption fade" data-x="200" data-y="220" data-speed="700" data-start="2300" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s9.png" alt="">
							</div>
							
							<div class="tp-caption sfb" data-x="780" data-y="500" data-speed="700" data-start="2500" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s10.png" alt="">
							</div>
							
							<div class="tp-caption customin" data-customin="scaleX:1.2;scaleY:1.2;" data-x="900" data-y="310" data-speed="700" data-start="2800" data-easing="easeOutBack">
                            	<img src="images/index/revolution-slider/s11.png" alt="">
							</div>
							
							<div class="tp-caption title sft" data-x="center" data-y="100" data-speed="700" data-start="3200" data-easing="easeOutBack">
                            	Let your business grow with us.
							</div>
							
				<!--<div class="tp-caption customin" data-customin="scaleX:0;scaleY:0;" data-x="center" data-y="170" data-speed="700" data-start="3500" data-easing="easeOutBack">
                            	<a class="btn btn-default" href="#">Learn more</a>
							</div>-->
							
							<div class="pattern"></div>
							
						</li>
					</ul>
				</div><!-- banner -->
			</div><!-- bannercontainer -->