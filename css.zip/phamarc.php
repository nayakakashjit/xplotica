<!doctype html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <meta name="keywords" content="">
    <meta name="description" content="">
    
    <title>Phamarc - Xplotica IT Solution</title>
    <meta name="title" content="Phamarc - Xplotica IT Solution"/>
    <meta name="description" content="Phamarc is a specially designed android application for the pharmaceutical industries, It provides complete solutions for the pharmaceutical Product management "/>
    <meta name= "keywords" content= "Pharmaceutical product management Application" />
    <meta name= "keywords" content= "Pharmaceutical product management System,Pharmaceutical product management Software,Pharmaceutical product management App,Pharmaceutical Brand Management System,Pharmaceutical Brand Management Software,Pharmaceutical Brand Management App,Pharmaceutical Feedback System,Pharmaceutical Feedback Software,Pharmaceutical Feedback App,Pharmaceutical Brand Feedback System,Pharmaceutical Brand Feedback Software,Pharmaceutical Brand Feedback App,Pharmaceutical Product Feedback System,Pharmaceutical product Feedback Software,Pharmaceutical product Feedback App,Pharmaceutical Monthly Field meeting System,Pharmaceutical Monthly Field meeting Software,Pharmaceutical Monthly Field meeting App,Pharmaceutical Chatting System,Pharmaceutical Chatting Software,Pharmaceutical Chatting App,Pharmaceutical Communication System,Pharmaceutical Communication Software,Pharmaceutical Communication App,Pharmaceutical Chatting System in Mumbai,Pharmaceutical Chatting Software in Mumbai,Pharmaceutical Chatting App in Mumbai,Pharmaceutical product management System in Mumbai,Pharmaceutical product management Software in Mumbai,Pharmaceutical product management App in Mumbai,Pharmaceutical Brand Management System in Mumbai,Pharmaceutical Brand Management Software in Mumbai,Pharmaceutical Brand Management App in Mumbai,Pharmaceutical Feedback System in Mumbai,Pharmaceutical Feedback Software in Mumbai,Pharmaceutical Feedback App in Mumbai,Pharmaceutical Brand Feedback System in Mumbai,Pharmaceutical Brand Feedback Software in Mumbai,Pharmaceutical Brand Feedback App in Mumbai,Pharmaceutical product Feedback System in Mumbai,Pharmaceutical product Feedback Software in Mumbai,Pharmaceutical product Feedback App in Mumbai,Pharmaceutical Monthly Field meeting System in Mumbai,Pharmaceutical Monthly Field meeting Software in Mumbai,Pharmaceutical Monthly Field meeting App in Mumbai,Pharmaceutical Communication System in Mumbai,Pharmaceutical Communication Software in Mumbai,Pharmaceutical Communication App in Mumbai,Pharmaceutical product management System in Ahmadabad,Pharmaceutical product management Software in Ahmadabad,Pharmaceutical product management App in Ahmadabad,Pharmaceutical Brand Management System in Ahmadabad,Pharmaceutical Brand Management Software in Ahmadabad,Pharmaceutical Brand Management App in Ahmadabad,Pharmaceutical Feedback System in Ahmadabad,Pharmaceutical Feedback Software in Ahmadabad,Pharmaceutical Feedback App in Ahmadabad,Pharmaceutical Brand Feedback System in Ahmadabad,Pharmaceutical Brand Feedback Software in Ahmadabad,Pharmaceutical Brand Feedback App in Ahmadabad,Pharmaceutical product Feedback System in Ahmadabad,Pharmaceutical product Feedback Software in Ahmadabad,Pharmaceutical product Feedback App in Ahmadabad,Pharmaceutical Monthly Field meeting System in Ahmadabad,Pharmaceutical Monthly Field meeting Software in Ahmadabad,Pharmaceutical Monthly Field meeting App in Ahmadabad,Pharmaceutical Communication System in Ahmadabad,Pharmaceutical Communication Software in Ahmadabad,Pharmaceutical Communication App in Ahmadabad,Pharmaceutical Chatting System in Ahmadabad,Pharmaceutical Chatting Software in Ahmadabad,Pharmaceutical Chatting App in Ahmadabad,Pharmaceutical product management System in Delhi,Pharmaceutical product management Software in Delhi,Pharmaceutical product management App in Delhi,Pharmaceutical Brand Management System in Delhi,Pharmaceutical Brand Management Software in Delhi,Pharmaceutical Brand Management App in Delhi,Pharmaceutical Feedback System in Delhi,Pharmaceutical Feedback Software in Delhi,Pharmaceutical Feedback App in Delhi,Pharmaceutical Brand Feedback System in Delhi,Pharmaceutical Brand Feedback Software in Delhi,Pharmaceutical Brand Feedback App in Delhi,Pharmaceutical product Feedback System in Delhi,Pharmaceutical product Feedback Software in Delhi,Pharmaceutical product Feedback App in Delhi,Pharmaceutical Monthly Field meeting System in Delhi,Pharmaceutical Monthly Field meeting Software in Delhi,Pharmaceutical Monthly Field meeting App in Delhi,Pharmaceutical Communication System in Delhi,Pharmaceutical Communication Software in Delhi,Pharmaceutical Communication App in Delhi,Pharmaceutical Chatting System in Delhi,Pharmaceutical Chatting Software in Delhi,Pharmaceutical Chatting App in Delhi,Pharmaceutical product management System in Chandigarh,Pharmaceutical product management Software in Chandigarh,Pharmaceutical product management App in Chandigarh,Pharmaceutical Brand Management System in Chandigarh,Pharmaceutical Brand Management Software in Chandigarh,Pharmaceutical Brand Management App in Chandigarh,Pharmaceutical Feedback System in Chandigarh,Pharmaceutical Feedback Software in Chandigarh,Pharmaceutical Feedback App in Chandigarh,Pharmaceutical Brand Feedback System in Chandigarh,Pharmaceutical Brand Feedback Software in Chandigarh,Pharmaceutical Brand Feedback App in Chandigarh,Pharmaceutical product Feedback System in Chandigarh,Pharmaceutical product Feedback Software in Chandigarh,Pharmaceutical product Feedback App in Chandigarh,Pharmaceutical Monthly Field meeting System in Chandigarh,Pharmaceutical Monthly Field meeting Software in Chandigarh,Pharmaceutical Monthly Field meeting App in Chandigarh,Pharmaceutical Communication System in Chandigarh,Pharmaceutical Communication Software in Chandigarh,Pharmaceutical Communication App in Chandigarh,Pharmaceutical Chatting System in Chandigarh,Pharmaceutical Chatting Software in Chandigarh,Pharmaceutical Chatting App in Chandigarh,Pharmaceutical product management System in Hyderabad,Pharmaceutical product management Software in Hyderabad,Pharmaceutical product management App in Hyderabad,Pharmaceutical Brand Management System in Hyderabad,Pharmaceutical Brand Management Software in Hyderabad,Pharmaceutical Brand Management App in Hyderabad,Pharmaceutical Feedback System in Hyderabad,Pharmaceutical Feedback Software in Hyderabad,Pharmaceutical Feedback App in Hyderabad,Pharmaceutical Brand Feedback System in Hyderabad,Pharmaceutical Brand Feedback Software in Hyderabad,Pharmaceutical Brand Feedback App in Hyderabad,Pharmaceutical product Feedback System in Hyderabad,Pharmaceutical product Feedback Software in Hyderabad,Pharmaceutical product Feedback App in Hyderabad,Pharmaceutical Monthly Field meeting System in Hyderabad,Pharmaceutical Monthly Field meeting Software in Hyderabad,Pharmaceutical Monthly Field meeting App in Hyderabad,Pharmaceutical Communication System in Hyderabad,Pharmaceutical Communication Software in Hyderabad,Pharmaceutical Communication App in Hyderabad,Pharmaceutical Chatting System in Hyderabad,Pharmaceutical Chatting Software in Hyderabad,Pharmaceutical Chatting App in Hyderabad,Pharmaceutical product management System in Chennai,Pharmaceutical product management Software in Chennai,Pharmaceutical product management App in Chennai,Pharmaceutical Brand Management System in Chennai,Pharmaceutical Brand Management Software in Chennai,Pharmaceutical Brand Management App in Chennai,Pharmaceutical Feedback System in Chennai,Pharmaceutical Feedback Software in Chennai,Pharmaceutical Feedback App in Chennai,Pharmaceutical Brand Feedback System in Chennai,Pharmaceutical Brand Feedback Software in Chennai,Pharmaceutical Brand Feedback App in Chennai,Pharmaceutical product Feedback System in Chennai,Pharmaceutical product Feedback Software in Chennai,Pharmaceutical product Feedback App in Chennai,Pharmaceutical Monthly Field meeting System in Chennai,Pharmaceutical Monthly Field meeting Software in Chennai,Pharmaceutical Monthly Field meeting App in Chennai,Pharmaceutical Communication System in Chennai,Pharmaceutical Communication Software in Chennai,Pharmaceutical Communication App in Chennai,Pharmaceutical Chatting System in Chennai,Pharmaceutical Chatting Software in Chennai,Pharmaceutical Chatting App in Chennai,Pharmaceutical product management System in Bangalore,Pharmaceutical product management Software in Bangalore,Pharmaceutical product management App in Bangalore,Pharmaceutical Brand Management System in Bangalore,Pharmaceutical Brand Management Software in Bangalore,Pharmaceutical Brand Management App in Bangalore,Pharmaceutical Feedback System in Bangalore,Pharmaceutical Feedback Software in Bangalore,Pharmaceutical Feedback App in Bangalore,Pharmaceutical Brand Feedback System in Bangalore,Pharmaceutical Brand Feedback Software in Bangalore,Pharmaceutical Brand Feedback App in Bangalore,Pharmaceutical product Feedback System in Bangalore,Pharmaceutical product Feedback Software in Bangalore,Pharmaceutical product Feedback App in Bangalore,Pharmaceutical Monthly Field meeting System in Bangalore,Pharmaceutical Monthly Field meeting Software in Bangalore,Pharmaceutical Monthly Field meeting App in Bangalore,Pharmaceutical Communication System in Bangalore,Pharmaceutical Communication Software in Bangalore,Pharmaceutical Communication App in Bangalore,Pharmaceutical Chatting System in Bangalore,Pharmaceutical Chatting Software in Bangalore,Pharmaceutical Chatting App in Bangalore" />
    
    <!-- FAVICON AND APPLE TOUCH  --> 
    <link rel="shortcut icon" href="favicon-180x180.png">  
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="favicon-180x180.png">
    
    <!-- FONTS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,300italic,300,500,500italic,700,700italic">
    
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="property/bootstrap/css/bootstrap.min.css"> 
    
    <!-- MT ICONS FONT -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="property/fonts/mt-icons/mt-icons.css">
    
    <!-- FANCYBOX -->
    <link rel="stylesheet" href="property/plugins/fancybox/jquery.fancybox.css">
	
	<!-- REVOLUTION SLIDER -->
    <link rel="stylesheet" href="property/plugins/revolutionslider/css/settings.css">
    
    <!-- OWL Carousel -->
    <link rel="stylesheet" href="property/plugins/owl-carousel/owl.carousel.css">
	<link rel="stylesheet" href="property/plugins/owl-carousel/owl.transitions.css">
	
	<!-- YOUTUBE PLAYER -->
    <link rel="stylesheet" href="property/plugins/ytplayer/css/jquery.mb.YTPlayer.min.css">
    
    <!-- ANIMATIONS -->
    <link rel="stylesheet" href="property/plugins/animations/animate.min.css">
    
    <!-- CUSTOM & PAGES STYLE -->
    <link rel="stylesheet" href="property/css/custom.css">
    <link rel="stylesheet" href="property/css/pages-style.css">
    
    <!-- STYLE SWITCHER -->
  <link rel="stylesheet" href="property/plugins/style-switcher/style-switcher.css">
    
    <!-- ALTERNATIVE STYLES -->
    <link rel="stylesheet" href="#" data-style="styles">
    

</head>
    <style>      
        input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    -moz-appearance:textfield;
}

a {
  text-decoration: none;
}
    </style>

<body>

	<div id="page-wrapper">
        
		<!-- HEADER -->
		<header>	
			
			<div id="header-top">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-8">
						
							<div class="widget widget-contact">
								
								<ul>
									<li>    
										<i class="mt-icon-telephone1"></i>
										<span class="hidden-xs" style="color: #fff;" style="text-decoration:none">+91 8867700428</span>
										<a class="visible-xs-inline" href="tel:+91 8867700428" style="text-decoration:none">+91 8867700428</a>
									</li>
									<li>
										<i class="mt-icon-mail"></i>
										<a href="#" style="text-decoration: none;">contact@xplotica.com</a>
									</li>
								</ul>
								
							</div><!-- widget-contact -->
							
						</div><!-- col -->
						<div class="col-sm-4">
						<div class="widget widget-contact">
								
								<ul style="text-align: right;margin-right: 3%;">
									<li>
									        <i class="mt-icon-telephone1"></i>
										<a href="support-xplotica.php">Support</a>
									</li>
									<li>
										<i class="fa fa-user" aria-hidden="true"></i>
										<a href="partner-xplotica.php">Partner</a>
									</li>
								
                                    <li>
										<i class="fa fa-rss" aria-hidden="true"></i>
										<a target="_blank" href="http://xplotica.com/blog">Blog</a>
									</li>
								</ul>
								
							</div>
							
							<!--<div class="widget widget-social">
												
								<div class="social-media">
								   <a class="facebook" href="#"><i class="mt-icon-facebook"></i></a>
									<a class="twitter" href="#"><i class="mt-icon-twitter"></i></a>
									<a class="google" href="#"><i class="mt-icon-google-plus"></i></a>
									<a class="pinterest" href="#"><i class="mt-icon-pinterest"></i></a>
									<a class="youtube" href="#"><i class="mt-icon-youtube-play"></i></a>                                    
								</div>
								
							</div>--><!-- widget-social -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->  
				
			</div><!-- header-top -->
			
			<div id="header">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							
							<!-- LOGO -->
							<div id="logo" style="margin-bottom: 3px;margin-top:3px;">
								<a href="index.php">
									<img src="property/images/logo xplotica.png" alt="">
								</a>
							</div><!-- logo -->
							
						</div><!-- col -->
						<div class="col-sm-10">
							
							<!-- MENU --> 
							<nav>
							
								<a id="mobile-menu-button" href="#"><i class="mt-icon-menu"></i></a>
												 
								<ul class="menu clearfix" id="menu">
									<li class="active">
										<a href="index.php" id="pd"><i class="mt-icon-home" style="font-weight:700;font-size: 16px;"></i></a>
									</li>
									<li>
										<a href="digi-edu.php" id="pd">Digiedu</a>
										
									</li>
									<!--<li class="dropdown">
												<a href="#" id="pd">Products</a>
												<ul>
													<li><a href="#">Trywis</a></li>
													<li><a href="#">Digiedu</a></li>
													<li><a href="#">Salon search</a></li>
													<li><a href="#">Pharmaceutical</a></li>
													<li><a href="#">Transportation</a></li>
												</ul>
											</li>-->
									<li>
										<a href="phamarc.php" id="pd">PHAMARC</a>
										
									</li>
									<li>
										<a href="transportation.php" id="pd">TRIPTRACS</a>
										
									</li>
									<!--<li class="dropdown">
										<a href="salon_search.php" id="pd">Salon</a>
										
									</li>-->
									
									<li class="dropdown">
												<a href="#" id="pd">INDUSTRY</a>
												<ul>
													
													<!--<li><a href="salon_search_industry.php">Salon</a></li> -->	
													<li><a href="Education-industry.php">Education</a></li>
													<li><a href="Pharmaceutical-industry.php">Pharmaceutical</a></li>
													<li><a href="transportation-industry.php">Transportation</a></li>
													
												</ul>
											</li>
											<li>
										<a href="contact-us.php" id="pd">CONTACT US</a>
										
									</li>
									
								</ul>
							
							</nav>
						
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->    
						
			</div><!-- header -->
		
		</header><!-- HEADER -->

 <link rel="stylesheet" href="property/css/custom_modal.css">
 <style>
.top{margin-top: 4%;}
.modal-style{border-radius: 0px;}
..input-group-addon {
               color: #009688 !important;
}
</style>
 <!-- CONTENT -->
        <div id="page-content">
            
            <div id="page-header">  
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            
                            <h4>Welcome to Phamarc</h4>
                            
                        </div><!-- col -->
                    </div><!-- row -->
                </div><!-- container -->    
            </div><!-- page-header -->
            <div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>About Phamarc</h3>
							<!--<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem</p>-->
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div>
            <div class="container">
			
			<p>Phamarc is a specially designed android application for the pharmaceutical industries, It provides complete solutions for the pharmaceutical Product Management Team (PMT) are easy to use and user-friendly modules are designed to reduce the paperwork. The automated feature has been designed to reduce the human interaction thus making processing error-free. The application is having Android interface for the employees for the official chatting purpose, monthly field meeting analysis and the reports.</p>
			<h6>It has different types of modules</h6>
			<ul>
			<li>Admin Module</li>
                        <li>Marketing Manager Module</li>
			<li>Product Manager Module</li>
			<li>Field Force Module (MR/ASM/RSM/ZSM)</li>
			<li>KOL Management Module</li>
			<li>Chemist Management Module</li>
			</ul>
			</div>
			<br>
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>Services we provide</h3>
							<!--<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem</p>-->
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			
			
			
			
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						
						<div class="service-box style-1 default wow fadeInDown">
								
							<!--<i class="mt-icon-screen1"></i>-->
							
							<div class="service-box-content">
								
								<h6>Customer Analysis</h6>
								
								<p>Is used to plain the geometrics of the customer, to know the customer needs  and the complete details of the customer through the simple process.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
					<div class="col-sm-4">
						
						<div class="service-box style-1 blue wow fadeInDown" data-wow-delay="0.2s">
								
							<!--<i class="mt-icon-screen1"></i>-->
							
							<div class="service-box-content">
								
								<h6>Strategic Business Planning</h6>
								
								<p>It can use for the value proposition and the company tactics to know the complete details about the company Strategic.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
					<div class="col-sm-4">
						
						<div class="service-box style-1 green wow fadeInDown" data-wow-delay="0.4s">
								
							<!--<i class="mt-icon-screen1"></i>-->
							
							<div class="service-box-content">
								
								<h6>Company based execution</h6>
								
								<p>It is helped in the company based execution management enables organizations to be more efficient, more effective and more capable of change than a functionally focused, traditional hierarchical management approach. These processes can impact the cost and revenue generation of an organization.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						
						<div class="service-box style-1 blue wow fadeInDown">
								
							<!--<i class="mt-icon-screen1"></i>-->
							
							<div class="service-box-content">
								
								<h6>Performance management</h6>
								
								<p>Performance management is helpful in checking the quality metrics of the entire company.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
					<div class="col-sm-4">
						
						<div class="service-box style-1 green wow fadeInDown" data-wow-delay="0.2s">
								
							<!--<i class="mt-icon-screen1"></i>-->
							
							<div class="service-box-content">
								
								<h6>Admin Module</h6>
								
								<p>The admin module is the main module which accessed by the authorized person in the company only for the office staff, product masters, employees, Doctor Module, Chemist Module.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
					<div class="col-sm-4">
						
						<div class="service-box style-1 default wow fadeInDown" data-wow-delay="0.4s">
								
							<!--<i class="mt-icon-screen1"></i>-->
							
							<div class="service-box-content">
								
								<h6>New Product Module</h6>
								
								<p>The new Product Module is designed to keep all the stack holder in close communication. The instant feedback from the Chemist, Doctor, and Field force will help in marketing new product.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						
						<div class="service-box style-1 green wow fadeInDown">
								
							<!--<i class="mt-icon-screen1"></i>-->
							
							<div class="service-box-content">
								
								<h6>Chemist Application</h6>
								
								<p>The chemist will able to give the immediate feedback about the product and the updates of the test results without any delay or the problem.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
					<div class="col-sm-4">
						
						<div class="service-box style-1 default wow fadeInDown" data-wow-delay="0.2s">
								
							<!--<i class="mt-icon-screen1"></i>-->
							
							<div class="service-box-content">
								
								<h6>Inter Office Chatting</h6>
								
								<p>It will be the official chatting between the office staff to know the updates or give information about them like leaves etc.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
					<div class="col-sm-4">
						
						<div class="service-box style-1 blue wow fadeInDown" data-wow-delay="0.4s">
								
							<!--<i class="mt-icon-screen1"></i>-->
							
							<div class="service-box-content">
								
								<h6>Doctor Application</h6>
								
								<p>The Doctors can give their feedback about the product and can give the suggestions related to the product and information about any updates.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			
			
			
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						
						<p class="text-center wow fadeInLeft"><img src="images/services/image-2.png" alt=""></p>
						
					</div><!-- col -->
					<div class="col-sm-6">
					
						<br><br>
						
						<h3>Official chatting application </h3>
						<p>It is the official chatting feature within the Phamarc application .</p>
						
						<br>
						
						<div class="service-box style-2 icon-left wow fadeInRight">
										
							
							
							<div class="service-box-content">
								
								<h6>Field Meeting</h6>
								
								<p>It is used for the monthly field meeting analysis and the report of those field meeting and discussions are made on its performance</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
						<div class="service-box style-2 icon-left wow fadeInRight">
										
							
							
							<div class="service-box-content">
								
								<h6>Daily Work</h6>
								
								<p>In the daily work the employee will get there daily work details, which they need to do and can update the status of the work.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
				
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
            
           <div class="container">
						<div class="row">
							<div class="col-sm-8">
                               
							</div><!-- col -->
                             <div class="col-sm-2 text-right">
							
								<!--<a class="btn btn-default" data-toggle="modal" data-target="#myModal-2">Book your Demo</a>-->
                                <a href="contact-us.php" class="btn btn-default">Book your Demo</a>
								
							</div>
							<div class="col-sm-2 text-right">
						
								<a class="btn btn-default" href="http://phamarc.com" target="_blank">More Details</a>
								
							</div><!-- col -->
						</div><!-- row -->
					</div>
			
	
        </div><!-- PAGE CONTENT -->
		
		<div class="modal fade" id="myModal-2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel-2">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content" style="margin-top: 28%;">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel-2">Enter your Details</h4>
                </div>

                <div class="modal-body">
                    <form id="myform" action="mailcareerpharma.php" method="POST">
 
					<div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-user" style="color:#3badad"></i></span>
						<input id="Text" type="text" class="form-control modal-style" name="name" placeholder="Name" pattern="[a-zA-Z0]+" required="">
					</div>
					<div class="input-group top">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-phone" style="color:#3badad"></i></span>
						<input id="Text" type="number" class="form-control modal-style" name="phone" placeholder="Phone number" pattern="^\d{10}$"  required="">
					</div>
							
					<div class="input-group top">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope" style="color:#3badad"></i></span>
						<input id="email" type="text" class="form-control modal-style" name="email" placeholder="Email" required="">
					</div>
					<div class="form-group top">
					  <textarea class="form-control modal-style" rows="4" id="comment" placeholder="Message" name="message" required=""></textarea>
					</div>
					
					
                        <center>
                            <button class="btn btn-success top" type="submit" id="btn_submit" style="background-color: #fe5e3e!important">Submit</button>
                        </center>
                    </form>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <!--<button type="button" class="btn btn-dialog">Ok</button>-->
                </div>
            </div>
            <!-- modal-content -->
        </div>
        <!-- modal-dialog -->
    </div>

		<?php include("footer.php"); ?>