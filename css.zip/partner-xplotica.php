<!doctype html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <meta name="keywords" content="">
    <meta name="description" content="">
    
    <title>Partner - Xplotica IT Solution</title>
    <meta name="title" content="Partner - Xplotica IT Solution"/>
    <meta name="description" content="Partnership. Our partners are soul of our company. Most of our sales takes place through our partner network. Therefore, our partners are also the integral part of our company"/>
    <meta name= "keywords" content= "Xplotica Partners" />
    
    <meta name= "keywords" content= "Xplotica Partners,Partners of xplotica,About Xplotica IT Solutions Pvt. Ltd., Xplotica,Xplotica IT Solutions,Xplotica IT Solutions Pvt. Ltd.,Xplotica IT Solutions,School Management System,Pharmaceutical product management Application,Transportation Management System,School Management System Application,Pharmaceutical Product Management System,Transportation Management System,Product based Applicaticon,Product based Applicaticon companies,Xplotica ITsolutions,Management application product in india,Product based Applicaticon companies in india,Product based Applicaticon companies in Bangalore" />
    
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
    <link href="css/mdb.min.css" rel="stylesheet">
    <!-- FAVICON AND APPLE TOUCH  --> 
    <link rel="shortcut icon" href="favicon-180x180.png">  
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="favicon-180x180.png">
    
    <!-- FONTS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,300italic,300,500,500italic,700,700italic">
    
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="property/bootstrap/css/bootstrap.min.css"> 
    
    <!-- MT ICONS FONT -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="property/fonts/mt-icons/mt-icons.css">
    
    <!-- FANCYBOX -->
    <link rel="stylesheet" href="property/plugins/fancybox/jquery.fancybox.css">
	
	<!-- REVOLUTION SLIDER -->
    <link rel="stylesheet" href="property/plugins/revolutionslider/css/settings.css">
    
    <!-- OWL Carousel -->
    <link rel="stylesheet" href="property/plugins/owl-carousel/owl.carousel.css">
	<link rel="stylesheet" href="property/plugins/owl-carousel/owl.transitions.css">
	
	<!-- YOUTUBE PLAYER -->
    <link rel="stylesheet" href="property/plugins/ytplayer/css/jquery.mb.YTPlayer.min.css">
    
    <!-- ANIMATIONS -->
    <link rel="stylesheet" href="property/plugins/animations/animate.min.css">
    
    <!-- CUSTOM & PAGES STYLE -->
    <link rel="stylesheet" href="property/css/custom.css">
    <link rel="stylesheet" href="property/css/pages-style.css">
    
    <!-- STYLE SWITCHER -->
    <link rel="stylesheet" href="property/plugins/style-switcher/style-switcher.css">
    
    <!-- ALTERNATIVE STYLES -->
    <link rel="stylesheet" href="#" data-style="styles">
    

</head>
   

<body>

	<div id="page-wrapper">
        
		<!-- HEADER -->
		<header>	
			
			<div id="header-top">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-8">
						
							<div class="widget widget-contact">
								
								<ul>
									<li>    
										<i class="mt-icon-telephone1"></i>
										<span class="hidden-xs" style="color: #fff;" style="text-decoration:none">+91 8867700428</span>
										<a class="visible-xs-inline" href="tel:+91 8867700428" style="text-decoration:none">+91 8867700428</a>
									</li>
									<li>
										<i class="mt-icon-mail"></i>
										<a href="#" style="text-decoration: none;">contact@xplotica.com</a>
									</li>
								</ul>
								
							</div><!-- widget-contact -->
							
						</div><!-- col -->
						<div class="col-sm-4">
						<div class="widget widget-contact">
								
								<ul style="text-align: right;margin-right: 3%;">
									<li>
									        <i class="mt-icon-telephone1"></i>
										<a href="support-xplotica.php">Support</a>
									</li>
									<li>
										<i class="fa fa-user" aria-hidden="true"></i>
										<a href="partner-xplotica.php">Partner</a>
									</li>
								
                                    <li>
										<i class="fa fa-rss" aria-hidden="true"></i>
										<a target="_blank" href="http://xplotica.com/blog">Blog</a>
									</li>
								</ul>
								
							</div>
							
							<!--<div class="widget widget-social">
												
								<div class="social-media">
								   <a class="facebook" href="#"><i class="mt-icon-facebook"></i></a>
									<a class="twitter" href="#"><i class="mt-icon-twitter"></i></a>
									<a class="google" href="#"><i class="mt-icon-google-plus"></i></a>
									<a class="pinterest" href="#"><i class="mt-icon-pinterest"></i></a>
									<a class="youtube" href="#"><i class="mt-icon-youtube-play"></i></a>                                    
								</div>
								
							</div>--><!-- widget-social -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->  
				
			</div><!-- header-top -->
			
			<div id="header">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							
							<!-- LOGO -->
							<div id="logo" style="margin-bottom: 3px;margin-top:3px;">
								<a href="index.php">
									<img src="property/images/logo xplotica.png" alt="">
								</a>
							</div><!-- logo -->
							
						</div><!-- col -->
						<div class="col-sm-10">
							
							<!-- MENU --> 
							<nav>
							
								<a id="mobile-menu-button" href="#"><i class="mt-icon-menu"></i></a>
												 
								<ul class="menu clearfix" id="menu">
									<li class="active">
										<a href="index.php" id="pd"><i class="mt-icon-home" style="font-weight:700;font-size: 16px;"></i></a>
									</li>
									<li>
										<a href="digi-edu.php" id="pd">Digiedu</a>
										
									</li>
									<!--<li class="dropdown">
												<a href="#" id="pd">Products</a>
												<ul>
													<li><a href="#">Trywis</a></li>
													<li><a href="#">Digiedu</a></li>
													<li><a href="#">Salon search</a></li>
													<li><a href="#">Pharmaceutical</a></li>
													<li><a href="#">Transportation</a></li>
												</ul>
											</li>-->
									<li>
										<a href="phamarc.php" id="pd">PHAMARC</a>
										
									</li>
									<li>
										<a href="transportation.php" id="pd">TRIPTRACS</a>
										
									</li>
									<!--<li class="dropdown">
										<a href="salon_search.php" id="pd">Salon</a>
										
									</li>-->
									
									<li class="dropdown">
												<a href="#" id="pd">INDUSTRY</a>
												<ul>
													
													<!--<li><a href="salon_search_industry.php">Salon</a></li> -->	
													<li><a href="Education-industry.php">Education</a></li>
													<li><a href="Pharmaceutical-industry.php">Pharmaceutical</a></li>
													<li><a href="transportation-industry.php">Transportation</a></li>
													
												</ul>
											</li>
											<li>
										<a href="contact-us.php" id="pd">CONTACT US</a>
										
									</li>
									
								</ul>
							
							</nav>
						
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->    
						
			</div><!-- header -->
		
		</header><!-- HEADER -->

  
<style>
 	#partner {
		height:320px;
        width: 1349px;
		background-image: url(images/suport/p1.jpg);
		background-repeat: no-repeat;
	} 
        .breadcrumbs a {
    color: #C33;
    background: url(images/suport/red-arrow.png) no-repeat right 7px;
    padding-right: 20px;
    margin-right: 10px;
}
	input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button { 
  -webkit-appearance: none; 
  margin: 0; 
}
	input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button { 
  -webkit-appearance: none; 
  margin: 0; 
}
</style>




 <div id="content-fluid">
	<div id="partner">

        <div class="row">
             <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12"></div>
            <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
               <!-- <br><br><br><br><br>
                <h3>We offer you a <span id="colr">single point</span> of contact to make the contact to make the entire operation
                    <span id="colr"> easy to manage and grow</span></h3>  -->       
            </div>
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        
            </div>
			  <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12"></div>
        </div>
        
        
     </div>
</div>

<div class="breadcrumbs" style="background:#fff;">
        <div class="container">
            <a href="http://xplotica.com/">Home</a> <strong>Partnership</strong>
        </div>
    </div>

<div class="container"> 
    	<div class="row">
      		<div class="col-md-8">
            	<div class="content-box">
      				<h2 class="heading">Partnership</h2>
      				<p class="left-border" style="text-align:justify;">Our partners are soul of our company. Most of our sales takes place through our partner network. 
                          Therefore, our partners are not only an integral part of our system but also pillars of our strength. 
                          They deliver and implement our knowledge and expertise to different segments of the market. 
                          It is their help which has enabled us to secure prominent position amongst the top Inventory &amp; Accounting Software of the world. 
                          <br><br>
                          Opportunity for Marg products is continuously growing in the market and this opportunity can be explored by proactively reaching out to Customers and providing the best service experience. 
                          This motivates us to keep expanding and strengthening our partner network.
                          <br>
					
                   
       			</div>    
  		    </div>
            <div class="col-md-4">
               <center> <h4>For Partner</h4></center>
                   <form id="myform" action="mailcareerpartner.php"  method="POST">
    <div class="md-form">
	  <i class="fa fa-user prefix"></i>
	  <input type="text" id="name" name="name"  maxlength="20"  class="form-control" pattern="[a-zA-Z0]+" required="" data-msg-required="Please Enter a valid Name" style="margin-bottom:25px;">
	  <label>NAME<span class="star">*</span></label>
	</div>
    
    <div class="md-form">
	  <i class="fa fa-envelope prefix"></i>
	  <input type="email" id="email" name="email" class="form-control" required="" data-msg-required="Please Enter a valid Email" style="margin-bottom:25px;">
	  <label>EMAIL<span class="star">*</span></label>
	</div>
		
	<div class="md-form">
	  <i class="fa fa-phone prefix"></i>
	  <input type="number" id="phone" name="phone" minlength="10" maxlength="10"  class="form-control" pattern="^\d{10}$"  required="" data-msg-required="Please Enter a 10 digit Number" style="margin-bottom:25px;"> 
	  <label>PHONE<span class="star">*</span></label>
	</div>
		
	<div class="md-form">
	  <i class="fa fa-pencil prefix"></i>
	  <textarea type="text" id="message" name="message" class="md-textarea"  required=""  data-msg-required="Please Enter Your Message" style="width: 100%;"></textarea>
	  <label>MESSAGE</label>
	</div>
      <center><button class="btn btn-success" type="submit"  id="btn_submit" style="background-color: #fe5e3e!important">Submit</button></center>
     
</form>    
           </div> 
        </div><!--# content part close #---> 
    </div>










<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="js/mdb.min.js"></script>

<?php include("footer.php"); ?>