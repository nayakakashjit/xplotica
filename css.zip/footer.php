 <!-- FOOTER -->
        <footer>
            
          <!--  <div id="footer-top" class="parallax" data-stellar-background-ratio="0.1">
				
				<div class="footer-top-shadow"></div>
				
				<div class="container">
					<div class="row">
						<div class="col-sm-8">
								
							<div class="widget widget-text">
								
								<div class="widget-text-newsletter">
									<h3><span class="text-default">Subscribe</span> to our info letter </h3>
									<p><em>Please enter your email id so that we can keep you updating about the updates in the application and new coming products.</em></p>
								</div>
								
							</div>
							
						</div>
						<div class="col-sm-4">
								
							<div class="widget widget-newsletter">
								
								<form name="newsletter" method="post" action="#">
									<fieldset>
						<input type="email" name="email" placeholder="your email address" style="padding-right:0px;">
										<input class="btn btn-default" type="submit" name="submit" value="Subscribe">
									</fieldset>
								</form>
								
							</div>
							
						</div>
					</div>
				</div>
				
			</div>-->
			
			 <div id="footer">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-2 col-sm-6">
							
							<div class="widget widget-text">
							
									<h6 class="widget-title">Useful Links</h6>
									<!--<p><img src="property/images/footer logo.png" alt=""></p>-->
								
									<p class="pd-5"><a href="index.php">Home</a></p>
									<!--<p class="pd-5"><a href="about_us.phpabout_us.php">About us</a></p>-->
									<p class="pd-5"><a href="carieer.php">Career</a></p>
									<!--<p class="pd-5"><a href="#">Portfolio</a></p>-->
									<p class="pd-5"><a target="_blank" href="http://xplotica.com/blog/">Blog</a></p>
                                	
                                    <p class="pd-5"><a href="portfolio.php">Portfolio</a></p>
									<!--<p class="pd-5"><a href="#">Privacy Policy</a></p>-->
				
							</div><!-- widget-text -->
							
							<!--<div class="widget widget-social">
												
								<div class="social-media">
								
									<a class="facebook" href=" https://www.facebook.com/xplotica1"><i class="mt-icon-facebook"></i></a>
									<a class="twitter" href="https://twitter.com/Xplotica_IT"><i class="mt-icon-twitter"></i></a>
									<a class="google" href="https://plus.google.com/u/1/115247681140071667187
"><i class="mt-icon-google-plus"></i></a>
									<a class="pinterest" href="https://in.pinterest.com/xploticait/"><i class="mt-icon-pinterest"></i></a>                                   
								
								</div>  
							
							</div>--><!-- widget-social -->
							
						</div><!-- col -->
						<div class="col-md-2 col-sm-6">
							
							<div class="widget widget-recent-posts">
														
								<h6 class="widget-title">Learn More</h6>
								
								    <p class="pd-5"><a href="http://digiedu.online/" target="_blank">DigiEdu</a></p>
									<p class="pd-5"><a href="#">Phamarc</a></p>
									<p class="pd-5"><a href="#">TripTrack</a></p>
									<!--<p class="pd-5"><a href="#">Salon search</a></p>-->
                                <p class="pd-5"><a target="_blank" href="http://trywis.com">Trywis</a></p>
								
								
							</div><!-- widget-recent-posts -->
							
						</div><!-- col -->
						<div class="col-md-4 col-sm-6">
							
							<div class="widget widget-recent-posts">
														
								<h6 class="widget-title">Connect With Us</h6>
								<div class="row">
								 <div class="col-sm-6">
								 <ul>
									<li style="margin-bottom: 5px;">
										<img class="ft-img" src="property/icons/Facebook.png" alt="Facebook">
										<a target="_blank" class="post-title" href=" https://www.facebook.com/xplotica1">Facebook</a><br>
									</li>
									<li style="margin-bottom: 5px;">
										<img class="ft-img" src="property/icons/Google+.png" alt="Google+">
										<a target="_blank" class="post-title" href="https://plus.google.com/u/1/115247681140071667187">Google+</a><br>
									</li>
									<li style="margin-bottom: 5px;">
										<img class="ft-img" src="property/icons/Linkedin.png" alt="Linkedin">
										<a target="_blank" class="post-title" href="https://www.linkedin.com/company-beta/3752547">Linkedin</a><br>
									</li>
								</ul>
								 </div>
								  <div class="col-sm-6">
								  <ul>
									<li style="margin-bottom: 5px;">
										<img class="ft-img" src="property/icons/Twitter.png" alt="Twitter">
										<a target="_blank" class="post-title" href="https://twitter.com/Xplotica_IT">Twitter</a><br>
									</li>
									<li style="margin-bottom: 5px;">
										<img class="ft-img" src="property/icons/Pinterest.png" alt="Pinterest">
										<a target="_blank" class="post-title" href="https://in.pinterest.com/xploticait">Pinterest</a><br>
									</li>
									<li style="margin-bottom: 5px;"/7>
										<img class="ft-img" src="property/icons/Instagram.png" alt="Instagram">
										<a target="_blank" class="post-title" href="https://www.instagram.com/xploticait">Instagram</a><br>
									</li>
								</ul>
								  </div>
								</div>
								
								
							</div><!-- widget-recent-posts -->
							
						</div><!-- col -->
						<div class="col-md-4 col-sm-6">
							
							<div class="widget widget-contact">
														
								<h6 class="widget-title">Contact Info</h6>
								
								<ul>
									<li>
										<i class="mt-icon-map-marker1"></i>
										Xplotica IT solutions Pvt LTD, #43,SGR Plaza, <br>Above Federal Bank,Marathahalli,Bengaluru, Karnataka 560037
									</li>
									<!--<li>    
										<i class="mt-icon-telephone1"></i>
										080-32552974
									</li>-->
									<li>
										<i class="mt-icon-mail"></i>
										<a href="mailto:contact@xplotica.com">contact@xplotica.com</a>
									</li>
									<!--<li>
										<i class="mt-icon-earth"></i>
										<a href="#">www.xplotica.com</a>
									</li>-->
								</ul>
								
							</div><!-- widget-contact -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->
				
			</div><!-- footer -->
			
			<div id="footer-bottom" style="background-color: rgb(62, 70, 76);">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							
							<div class="widget widget-text">
								
								<div>
									<p>Xplotica &copy; 2015. All Rights Reserved</p>
								</div>
								
							</div><!-- widget-text -->
							
						</div><!-- col -->
						<!--<div class="col-sm-8">
							
							<div class="widget widget-pages">
								
								<ul>
									<li><a href="#">Home</a></li>
									<li><a href="#">About</a></li>
									<li><a href="#">Services</a></li>
									<li><a href="#">Portfolio</a></li>
									<li><a href="#">Blog</a></li>
									<li><a href="#">Contact</a></li>
								</ul>
								
							</div><!-- widget-pages -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->
			
			</div><!-- footer-bottom -->
            
        </footer><!-- FOOTER -->
        
    </div><!-- PAGE-WRAPPER -->
    
    
    <!-- GO TOP -->
    <a id="go-top"><i class="mt-icon-arrow-up2"></i></a>
    
    
    <!-- STYLE SWITCHER -->
   <div id="style-switcher"></div>
    
    
    <!-- jQUERY -->
    <script src="property/plugins/jquery/jquery-2.1.4.min.js"></script>
	
    <!-- BOOTSTRAP JS -->
    <script src="property/bootstrap/js/bootstrap.min.js"></script>
    
    <!-- VIEWPORT -->
    <script src="property/plugins/viewport/jquery.viewport.js"></script>
    
    <!-- MENU -->
	<script src="property/plugins/menu/hoverIntent.js"></script>
    <script src="property/plugins/menu/superfish.js"></script>
    
    <!-- FANCYBOX -->
    <script src="property/plugins/fancybox/jquery.fancybox.pack.js"></script>
	
	<!-- REVOLUTION SLIDER -->
    <script src="property/plugins/revolutionslider/js/jquery.themepunch.tools.min.js"></script>
    <script src="property/plugins/revolutionslider/js/jquery.themepunch.revolution.min.js"></script>
    
    <!-- OWL Carousel -->
    <script src="property/plugins/owl-carousel/owl.carousel.min.js"></script>
    
    <!-- PARALLAX -->
    <script src="property/plugins/parallax/jquery.stellar.min.js"></script>
    
    <!-- ISOTOPE -->
    <script src="property/plugins/isotope/imagesloaded.pkgd.min.js"></script>
    <script src="property/plugins/isotope/isotope.pkgd.min.js"></script>
    
    <!-- PLACEHOLDER -->
    <script src="property/plugins/placeholders/jquery.placeholder.min.js"></script>
    
    <!-- CONTACT FORM VALIDATE & SUBMIT -->
    <script src="property/plugins/validate/jquery.validate.min.js"></script>
    <script src="property/plugins/submit/jquery.form.min.js"></script>
    
    <!-- GOOGLE MAPS -->
    <script src="http://maps.google.com/maps/api/js?sensor=false"></script>
    <script src="property/plugins/googlemaps/gmap3.min.js"></script>
    
    <!-- CHARTS -->
	<script src="property/plugins/charts/jquery.easypiechart.min.js"></script>
	
	<!-- COUNTER -->
	<script src="property/plugins/counter/jQuerySimpleCounter.js"></script>
	
	<!-- STATISTICS -->
	<script src="property/plugins/statistics/chart.min.js"></script>
	
	<!-- YOUTUBE PLAYER -->
    <script src="property/plugins/ytplayer/jquery.mb.YTPlayer.min.js"></script>
	
	<!-- INSTAFEED -->
	<script src="property/plugins/instafeed/instafeed.min.js"></script>
    
    <!-- ANIMATIONS -->
    <script src="property/plugins/animations/wow.min.js"></script>
	
	<!-- COUNTDOWN -->
    <script src="property/plugins/countdown/jquery.countdown.min.js"></script>
    
    <!-- CUSTOM JS -->
    <script src="property/js/custom.js"></script>
     
    <!-- STYLE SWITCHER -->
  <!-- <script src="property/plugins/style-switcher/jquery.cookie.js"></script>
   <script src="property/plugins/style-switcher/style-switcher.js"></script>-->
     
</body>
</html>
