<!doctype html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    
    <title>Transportation Management Industry - Xplotica IT Solution</title>
    <meta name="title" content="Transportation Management Industry - Xplotica IT Solution"/>
    <meta name="description" content="Xplotica understands exceptionally well what need is and what is amusement. As per that, we construct creative Transportation Management software "/>
    <meta name= "keywords" content= "Transportation Management System" />
    <meta name= "keywords" content= "cab management system,auto management system,bus management system,school bus management system,logistics and transportation,logistics management,logistics software,employee transport management system,employee transportation services,employee transportation,transport management software India,transport management technology,employee transportation services in Bangalore,employee transport management,employee transportation solution,employee transportation services in Hyderabad,transport automation system,transportation management solutions,student transport management system,student transportation services,student transportation,student transport management,student transportation solution,student transportation services in Hyderabad" />
    
    <!-- FAVICON AND APPLE TOUCH  --> 
    <link rel="shortcut icon" href="favicon-180x180.png">  
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="favicon-180x180.png">
    
    <!-- FONTS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,300italic,300,500,500italic,700,700italic">
    
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="property/bootstrap/css/bootstrap.min.css"> 
    
    <!-- MT ICONS FONT -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="property/fonts/mt-icons/mt-icons.css">
    
    <!-- FANCYBOX -->
    <link rel="stylesheet" href="property/plugins/fancybox/jquery.fancybox.css">
	
	<!-- REVOLUTION SLIDER -->
    <link rel="stylesheet" href="property/plugins/revolutionslider/css/settings.css">
    
    <!-- OWL Carousel -->
    <link rel="stylesheet" href="property/plugins/owl-carousel/owl.carousel.css">
	<link rel="stylesheet" href="property/plugins/owl-carousel/owl.transitions.css">
	
	<!-- YOUTUBE PLAYER -->
    <link rel="stylesheet" href="property/plugins/ytplayer/css/jquery.mb.YTPlayer.min.css">
    
    <!-- ANIMATIONS -->
    <link rel="stylesheet" href="property/plugins/animations/animate.min.css">
    
    <!-- CUSTOM & PAGES STYLE -->
    <link rel="stylesheet" href="property/css/custom.css">
    <link rel="stylesheet" href="property/css/pages-style.css">
    
    <!-- STYLE SWITCHER -->
  <link rel="stylesheet" href="property/plugins/style-switcher/style-switcher.css">
    
    <!-- ALTERNATIVE STYLES -->
    <link rel="stylesheet" href="#" data-style="styles">
    

</head>
    <style>      
        input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    -moz-appearance:textfield;
}

a {
  text-decoration: none;
}
    </style>

<body>

	<div id="page-wrapper">
        
		<!-- HEADER -->
		<header>	
			
			<div id="header-top">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-8">
						
							<div class="widget widget-contact">
								
								<ul>
									<li>    
										<i class="mt-icon-telephone1"></i>
										<span class="hidden-xs" style="color: #fff;" style="text-decoration:none">+91 8867700428</span>
										<a class="visible-xs-inline" href="tel:+91 8867700428" style="text-decoration:none">+91 8867700428</a>
									</li>
									<li>
										<i class="mt-icon-mail"></i>
										<a href="#" style="text-decoration: none;">contact@xplotica.com</a>
									</li>
								</ul>
								
							</div><!-- widget-contact -->
							
						</div><!-- col -->
						<div class="col-sm-4">
						<div class="widget widget-contact">
								
								<ul style="text-align: right;margin-right: 3%;">
									<li>
									        <i class="mt-icon-telephone1"></i>
										<a href="support-xplotica.php">Support</a>
									</li>
									<li>
										<i class="fa fa-user" aria-hidden="true"></i>
										<a href="partner-xplotica.php">Partner</a>
									</li>
								
                                    <li>
										<i class="fa fa-rss" aria-hidden="true"></i>
										<a target="_blank" href="http://xplotica.com/blog">Blog</a>
									</li>
								</ul>
								
							</div>
							
							<!--<div class="widget widget-social">
												
								<div class="social-media">
								   <a class="facebook" href="#"><i class="mt-icon-facebook"></i></a>
									<a class="twitter" href="#"><i class="mt-icon-twitter"></i></a>
									<a class="google" href="#"><i class="mt-icon-google-plus"></i></a>
									<a class="pinterest" href="#"><i class="mt-icon-pinterest"></i></a>
									<a class="youtube" href="#"><i class="mt-icon-youtube-play"></i></a>                                    
								</div>
								
							</div>--><!-- widget-social -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->  
				
			</div><!-- header-top -->
			
			<div id="header">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							
							<!-- LOGO -->
							<div id="logo" style="margin-bottom: 3px;margin-top:3px;">
								<a href="index.php">
									<img src="property/images/logo xplotica.png" alt="">
								</a>
							</div><!-- logo -->
							
						</div><!-- col -->
						<div class="col-sm-10">
							
							<!-- MENU --> 
							<nav>
							
								<a id="mobile-menu-button" href="#"><i class="mt-icon-menu"></i></a>
												 
								<ul class="menu clearfix" id="menu">
									<li class="active">
										<a href="index.php" id="pd"><i class="mt-icon-home" style="font-weight:700;font-size: 16px;"></i></a>
									</li>
									<li>
										<a href="digi-edu.php" id="pd">Digiedu</a>
										
									</li>
									<!--<li class="dropdown">
												<a href="#" id="pd">Products</a>
												<ul>
													<li><a href="#">Trywis</a></li>
													<li><a href="#">Digiedu</a></li>
													<li><a href="#">Salon search</a></li>
													<li><a href="#">Pharmaceutical</a></li>
													<li><a href="#">Transportation</a></li>
												</ul>
											</li>-->
									<li>
										<a href="phamarc.php" id="pd">PHAMARC</a>
										
									</li>
									<li>
										<a href="transportation.php" id="pd">TRIPTRACS</a>
										
									</li>
									<!--<li class="dropdown">
										<a href="salon_search.php" id="pd">Salon</a>
										
									</li>-->
									
									<li class="dropdown">
												<a href="#" id="pd">INDUSTRY</a>
												<ul>
													
													<!--<li><a href="salon_search_industry.php">Salon</a></li> -->	
													<li><a href="Education-industry.php">Education</a></li>
													<li><a href="Pharmaceutical-industry.php">Pharmaceutical</a></li>
													<li><a href="transportation-industry.php">Transportation</a></li>
													
												</ul>
											</li>
											<li>
										<a href="contact-us.php" id="pd">CONTACT US</a>
										
									</li>
									
								</ul>
							
							</nav>
						
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->    
						
			</div><!-- header -->
		
		</header><!-- HEADER -->


  <div id="page-content"> <!--PAGE CONTENT -->
  
      <div id="page-header">  
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            
                            <h4>WELCOME TO TRANSPORTATION INDUSTRY</h4>
                            
                        </div><!-- col -->
                    </div><!-- row -->
                </div><!-- container -->    
            </div><!-- page-header -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>Transportation Management Industry</h3>
							<!--<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem.</p>-->
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-8">
						
						<div class="row">
							<div class="col-sm-6">
								
								<h4><span class="text-default">Transportation</span> Management software.</h4>
								<p>Xplotica understands exceptionally well what need is and what is amusement. As per that, we construct creative Transportation Management software and mobile applications for empower transportation management to locate the least demanding answers for the greater part of their intricate issues.</p>
								
							</div><!-- col -->
							<div class="col-sm-6">
								
								<p>Now-a-days the greatest test for transportation organizations is accomplishing consumer loyalty and holding them. At the point when goes to the Logistics business, alongside meeting client desires, moment support and wellbeing and security are the greatest difficulties that make logistics organizations try hard to be in the competition. Xplotica innovative Transportation Management Software can be a solution for all these normal issues.</p>
								
							</div>
                            <p></p><!-- col -->
						</div><!-- row -->
						
						<br>
						
						<ul class="arrow-list">
							<li class="text-uppercase"><strong>Vehicle Booking</strong></li>
							<li class="text-uppercase"><strong>Cab tracking</strong></li>
							<li class="text-uppercase"><strong>Getting real-time inventory status</strong></li>
							<li class="text-uppercase"><strong>Area based administration</strong></li>
						</ul>
						
					</div><!-- col -->
					<div class="col-sm-4">
						
						<p><img class="wow fadeInRight" src="images and icons/transort.jpg" alt=""></p>
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<section class="full-section dark-section parallax" id="section-17" data-stellar-background-ratio="0.1" style="margin-top: 30px;">
				
				<div class="full-section-overlay-color"></div>
				
				<div class="full-section-container">
				
					<div class="container">
						<div class="row">
							<div class="col-sm-12">
								
								<h3 class="text-center"><strong>Sometimes <span class="text-default">we win</span>, sometimes <span class="text-default">we 
								learn</span>.</strong></h3>
								
							</div><!-- col -->
						</div><!-- row -->
					</div><!-- container -->
					
					<br><br>
					
					<div class="container">
						<div class="row">
							<div class="col-sm-3">
								
								<div class="pie-chart-container">
											
									<div class="pie-chart blue" data-percent="95" data-size="170" data-line-width="4" data-track-color="transparent" data-bar-color="#00d2ed">
										
										<i class="mt-icon-myspace"></i>
										
										<div class="pie-chart-details">
											
											<h1><span class="value"></span>%</h1>
											<h6>Happy Clients</h6>
										
										</div><!-- pie-chart-percent -->													
									
									</div><!-- pie-chart -->
								
								</div><!-- pie-chart-container -->
								
							</div><!-- col -->
							<div class="col-sm-3">
								
								<div class="pie-chart-container">
											
									<div class="pie-chart default" data-percent="75" data-size="170" data-line-width="4" data-track-color="transparent" data-bar-color="#fe5e3e">
										
										<i class="mt-icon-document3"></i>
										
										<div class="pie-chart-details">
											
											<h1><span class="value"></span>%</h1>
											<h6>Work</h6>
										
										</div><!-- pie-chart-percent -->													
									
									</div><!-- pie-chart -->
								
								</div><!-- pie-chart-container -->
								
							</div><!-- col -->
							<div class="col-sm-3">
								
								<div class="pie-chart-container">
											
									<div class="pie-chart green" data-percent="58" data-size="170" data-line-width="4" data-track-color="transparent" data-bar-color="#00e095">
										
										<i class="mt-icon-speechbubble1"></i>
										
										<div class="pie-chart-details">
											
											<h1><span class="value"></span>%</h1>
											<h6>Comunication</h6>
										
										</div><!-- pie-chart-percent -->													
									
									</div><!-- pie-chart -->
								
								</div><!-- pie-chart-container -->
								
							</div><!-- col -->
							<div class="col-sm-3">
								
								<div class="pie-chart-container">
											
									<div class="pie-chart default" data-percent="99" data-size="170" data-line-width="4" data-track-color="transparent" data-bar-color="#fe5e3e">
										
										<i class="mt-icon-trophy"></i>
										
										<div class="pie-chart-details">
											
											<h1><span class="value"></span>%</h1>
											<h6>Design</h6>
										
										</div><!-- pie-chart-percent -->													
									
									</div><!-- pie-chart -->
								
								</div><!-- pie-chart-container -->
								
							</div><!-- col -->
						</div><!-- row -->
					</div><!-- container -->

					
				</div><!-- full-section-container -->
				
			</section><!-- full-section -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>Features of Our Application</h3>
							<!--<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem.</p>-->
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-5">
						
						<div class="service-box style-2 icon-right wow fadeInLeft">
										
							<i class="mt-icon-screen1"></i>
							
							<div class="service-box-content">
								
								<h6>Data centric admin panel</h6>
								
								<p>The admin panel is connected with the data-centric device which is helpful to get the lost data in the admin panel from the database.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
						<div class="service-box style-2 icon-right wow fadeInLeft">
										
							<i class="mt-icon-picture"></i>
							
							<div class="service-box-content">
								
								<h6>Clean &amp; modern design</h6>
								
								<p>Our Design and development team has worked very keenly to improvise the application according to the latest Industry changes and trends.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
						<div class="service-box style-2 icon-right wow fadeInLeft">
										
							<i class="mt-icon-word"></i>
							
							<div class="service-box-content">
								
								<h6>Complete documentation</h6>
								
								<p>Mobile Apps leverages the functionality of App development to add sign-in, push notifications, and data sync to your mobile app. Connect your app to enterprise systems and on-premises resources. Scale your app to millions of customers across multiple geographies.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
					<div class="col-sm-2">
						
						<br><br class="hidden-xs">
						
						<p class="text-center"><img class="wow pulse" src="images and icons/transportation.png" alt=""></p>
						
						<br><br>
						
					</div><!-- col -->
					<div class="col-sm-5">
						
						<div class="service-box style-2 icon-left wow fadeInRight">
										
							<i class="mt-icon-document3"></i>
							
							<div class="service-box-content">
								
								<h6>Easy to customize</h6>
								
								<p>The process of settings in the application are very simple without any complications the user can customize the app easily.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
						<div class="service-box style-2 icon-left wow fadeInRight">
										
							<i class="mt-icon-smartphone1"></i>
							
							<div class="service-box-content">
								
								<h6>Responsive</h6>
								
								<p>The Web, Android, and IOS apps have been developed for all types of devices ranging from mobile, Tab, Small, medium and large screen desktop or laptop.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
						<div class="service-box style-2 icon-left wow fadeInRight">
										
							<i class="mt-icon-stars"></i>
							
							<div class="service-box-content">
								
								<h6>Light And Fast</h6>
								
								<p>The app will not take the much space to install in the device. If you open the app, the data is already loaded and ready to go.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			<div class="container">
						<div class="row">
							<div class="col-sm-6">
							</div><!-- col -->
							<div class="col-sm-6 text-right">
						
								<!--<a class="btn btn-default" href="http://xplotica.com/digiedu">More Details</a>-->
								
							</div><!-- col -->
						</div><!-- row -->
					</div>
			
								
							</div>
						</div>
					</div>
					
				</div>
				
			</section> -->
			

  
  
          </div>   <!-- PAGE CONTENT END -->
<?php include("footer.php"); ?>