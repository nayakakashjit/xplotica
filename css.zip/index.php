<!doctype html>
<html>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    
       <title>Xplotica IT Solutions</title>
    <meta name="title" content="Xplotica IT Solutions" />
    <meta name="description" content="Here in Xplotica IT Solutions, we cater technology. We work on the cutting edge technology and keep our self updated according to the recent technology" />
    <meta name="keywords" content="Xplotica" />
     <meta name="keywords" content="Xplotica IT Solutions" />
     <meta name="keywords" content="School Management System" />
     <meta name="keywords" content="Pharmaceutical product management Application" />
     <meta name="keywords" content="Transportation Management System" />
     <meta name="keywords" content="School Management System Application" />
     <meta name="keywords" content="Pharmaceutical Product Management System" />
     <meta name="keywords" content="Transportation Management System" />
    <meta name= "keywords" content= "Xplotica,Xplotica IT Solutions,School Management System,Pharmaceutical product management Application,Transportation Management System,School Management System Application,Pharmaceutical Product Management System,Transportation Management System" />
    
    <!-- FAVICON AND APPLE TOUCH  --> 
    <link rel="shortcut icon" href="favicon-180x180.png">  
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="favicon-180x180.png">
    
    <!-- FONTS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,300italic,300,500,500italic,700,700italic">
    
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="property/bootstrap/css/bootstrap.min.css"> 
    
    <!-- MT ICONS FONT -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="property/fonts/mt-icons/mt-icons.css">
    
    <!-- FANCYBOX -->
    <link rel="stylesheet" href="property/plugins/fancybox/jquery.fancybox.css">
	
	<!-- REVOLUTION SLIDER -->
    <link rel="stylesheet" href="property/plugins/revolutionslider/css/settings.css">
    
    <!-- OWL Carousel -->
    <link rel="stylesheet" href="property/plugins/owl-carousel/owl.carousel.css">
	<link rel="stylesheet" href="property/plugins/owl-carousel/owl.transitions.css">
	
	<!-- YOUTUBE PLAYER -->
    <link rel="stylesheet" href="property/plugins/ytplayer/css/jquery.mb.YTPlayer.min.css">
    
    <!-- ANIMATIONS -->
    <link rel="stylesheet" href="property/plugins/animations/animate.min.css">
    
    <!-- CUSTOM & PAGES STYLE -->
    <link rel="stylesheet" href="property/css/custom.css">
    <link rel="stylesheet" href="property/css/pages-style.css">
    
    <!-- STYLE SWITCHER -->
  <link rel="stylesheet" href="property/plugins/style-switcher/style-switcher.css">
    
    <!-- ALTERNATIVE STYLES -->
    <link rel="stylesheet" href="#" data-style="styles">
    

</head>
    <style>      
        input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    -moz-appearance:textfield;
}

a {
  text-decoration: none;
}
    </style>

<body>

	<div id="page-wrapper">
        
		<!-- HEADER -->
		<header>	
			
			<div id="header-top">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-8">
						
							<div class="widget widget-contact">
								
								<ul>
									<li>    
										<i class="mt-icon-telephone1"></i>
										<span class="hidden-xs" style="color: #fff;" style="text-decoration:none">+91 8867700428</span>
										<a class="visible-xs-inline" href="tel:+91 8867700428" style="text-decoration:none">+91 8867700428</a>
									</li>
									<li>
										<i class="mt-icon-mail"></i>
										<a href="#" style="text-decoration: none;">contact@xplotica.com</a>
									</li>
								</ul>
								
							</div><!-- widget-contact -->
							
						</div><!-- col -->
						<div class="col-sm-4">
						<div class="widget widget-contact">
								
								<ul style="text-align: right;margin-right: 3%;">
									<li>
									        <i class="mt-icon-telephone1"></i>
										<a href="support-xplotica.php">Support</a>
									</li>
									<li>
										<i class="fa fa-user" aria-hidden="true"></i>
										<a href="partner-xplotica.php">Partner</a>
									</li>
								
                                    <li>
										<i class="fa fa-rss" aria-hidden="true"></i>
										<a target="_blank" href="http://xplotica.com/blog">Blog</a>
									</li>
								</ul>
								
							</div>
							
							<!--<div class="widget widget-social">
												
								<div class="social-media">
								   <a class="facebook" href="#"><i class="mt-icon-facebook"></i></a>
									<a class="twitter" href="#"><i class="mt-icon-twitter"></i></a>
									<a class="google" href="#"><i class="mt-icon-google-plus"></i></a>
									<a class="pinterest" href="#"><i class="mt-icon-pinterest"></i></a>
									<a class="youtube" href="#"><i class="mt-icon-youtube-play"></i></a>                                    
								</div>
								
							</div>--><!-- widget-social -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->  
				
			</div><!-- header-top -->
			
			<div id="header">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							
							<!-- LOGO -->
							<div id="logo" style="margin-bottom: 3px;margin-top:3px;">
								<a href="index.php">
									<img src="property/images/logo xplotica.png" alt="">
								</a>
							</div><!-- logo -->
							
						</div><!-- col -->
						<div class="col-sm-10">
							
							<!-- MENU --> 
							<nav>
							
								<a id="mobile-menu-button" href="#"><i class="mt-icon-menu"></i></a>
												 
								<ul class="menu clearfix" id="menu">
									<li class="active">
										<a href="index.php" id="pd"><i class="mt-icon-home" style="font-weight:700;font-size: 16px;"></i></a>
									</li>
									<li>
										<a href="digi-edu.php" id="pd">Digiedu</a>
										
									</li>
									<!--<li class="dropdown">
												<a href="#" id="pd">Products</a>
												<ul>
													<li><a href="#">Trywis</a></li>
													<li><a href="#">Digiedu</a></li>
													<li><a href="#">Salon search</a></li>
													<li><a href="#">Pharmaceutical</a></li>
													<li><a href="#">Transportation</a></li>
												</ul>
											</li>-->
									<li>
										<a href="phamarc.php" id="pd">PHAMARC</a>
										
									</li>
									<li>
										<a href="transportation.php" id="pd">TRIPTRACS</a>
										
									</li>
									<!--<li class="dropdown">
										<a href="salon_search.php" id="pd">Salon</a>
										
									</li>-->
									
									<li class="dropdown">
												<a href="#" id="pd">INDUSTRY</a>
												<ul>
													
													<!--<li><a href="salon_search_industry.php">Salon</a></li> -->	
													<li><a href="Education-industry.php">Education</a></li>
													<li><a href="Pharmaceutical-industry.php">Pharmaceutical</a></li>
													<li><a href="transportation-industry.php">Transportation</a></li>
													
												</ul>
											</li>
											<li>
										<a href="contact-us.php" id="pd">CONTACT US</a>
										
									</li>
									
								</ul>
							
							</nav>
						
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->    
						
			</div><!-- header -->
		
		</header><!-- HEADER -->

   <link rel="stylesheet" href="property/css/custom_modal.css">
<style>
.top{margin-top: 4%;}
.modal-style{border-radius: 0px;}
}
</style>
<style>
    .pfoliotab{
    text-align: center;
    margin-bottom: 40px;
}
    </style>
  <div id="page-content"> <!--PAGE CONTENT -->
          <?php include("index_page_slider.php"); ?>
           
		   <div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>How we strengthen your reach ?</h3>
							<p>We provide our products in the range of the Android, IOS and web application to increase your market depth and reach to the customers.</p>
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="process-steps process-3-steps">
							<div class="step wow fadeInDown">
								<!--<i class="mt-icon-screen1"></i>-->
								<!--<img class="" src="images/index/revolution-slider/web.png" alt="">-->
								 <img src="images/index/revolution-slider/web.png"  
								  onmouseover="this.src='images/index/revolution-slider/web1.png'" 
								onmouseout="this.src='images/index/revolution-slider/web.png'" 
								class="date-left" />
								<div class="step-details">
									<h6>WEB</h6>
									<p>For ~ 3.8 Billion of Internet user worldwide, for data driven activities Web application is best choice so we provide our Admin panel in the Web first</p>
								</div><!-- step-details -->
							</div><!-- step -->
							
							<div class="step wow fadeInDown" data-wow-delay="0.2s">
								<!--<i class="mt-icon-films"></i>-->
								<img src="images/index/revolution-slider/android.png"  
									  onmouseover="this.src='images/index/revolution-slider/android1.png'" 
									onmouseout="this.src='images/index/revolution-slider/android.png'" 
									class="date-left" />
								<div class="step-details">
									<h6>ANDROID</h6>
									<p>The increasing no. of mobile, maximum user base in India and Asia is Android. Our every product available in complete user friendly Android app.</p>
								</div><!-- step-details -->
							</div><!-- step -->
							
							<div class="step wow fadeInDown" data-wow-delay="0.4s">
								<!--<i class="mt-icon-android"></i>-->
								<img src="images/index/revolution-slider/ios.png"  
									  onmouseover="this.src='images/index/revolution-slider/ios1.png'" 
									onmouseout="this.src='images/index/revolution-slider/ios.png'" 
									class="date-left" />
								<div class="step-details">
									<h6>IOS</h6>
									<p>Our product availability for the IOS platform increase your reach to the customer and your presence more impactful.</p>
								</div><!-- step-details -->
							</div><!-- step -->
							
						</div><!-- process-steps -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>What we offer</h3>
							<p>We offer software products in the wide range of Industry presence like: Pharmaceutical, Education, Corporate cab management and logistics. </p>
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
						<div class="container">
				<div class="row">
					<div class="col-sm-8">
						
						<div class="vertical-tabs big-tabs">
						
							<ul class="nav nav-tabs">
								<li class="active"><a href="#tab-1-1" data-toggle="tab">
                                    <img class="wow fadeInRight" src="images%20and%20icons/digi%20edu.png" alt="">&nbsp;Education</a>
                                </li>
								<li><a href="#tab-1-2" data-toggle="tab"> 
                                    <img class="wow fadeInRight" src="images%20and%20icons/phamarc.png" alt="">&nbsp;Pharmaceutical</a>
                                </li>
								<li><a href="#tab-1-3" data-toggle="tab">
                                    <img class="wow fadeInRight" src="images%20and%20icons/Triptracs.png" alt="">&nbsp;</i>Transportation</a></li>
								<!--<li><a href="#tab-1-4" data-toggle="tab"><i class="mt-icon-folder1"></i>Salon search</a></li>-->
								<!--<li><a href="#tab-1-5" data-toggle="tab"><i class="mt-icon-tablet1"></i>Transportation</a></li>-->
							</ul>                                            
						
							<div class="tab-content">
								<div class="tab-pane fade in active" id="tab-1-1">
									
						<h4> A one-stop management solution for the School and Education <span class="text-default">industry.</span></h4>
									<br>
									
									<p> DigiEdu is a complete school management application designed for Android and the web. It is easy to use, completely optimized data-driven application which reduces the human effort and paperwork for the management and thus helps the Organizations to focus more towards the Students and organizational growth unanimously. Parent module helps parents to keep track of the daily activity of their kids and help them to make a digital presence with them with transportation tracking and live streaming features.
</p>
									
									
									
									<br>
									
									
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-1-2">
									
									<h4>The pharmaceutical business finds, creates, delivers, and markets medicine or pharmaceutical medicine for use as  <span class="text-default">medications.</span></h4>
									<br>
									
									<p>Pharma is a Pharmaceutical Management Software product, designed for completely keeping the Pharmaceutical Sales and Marketing activities in the center. It is designed to optimize the day to day work of the Marketing and Sales team and help them to increase the output. It caters the complete hierarchy and diversity of the Pharmacy Industry. It provides a direct and prompt flow of information from the Doctor, Chemist and Field force to the Product manager and marketing team and thus helps them to design better marketing strategy for the Products.</p>
									
									
									<br>
									
									
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-1-3">
									
									<h4>Corporate cab management  and logistics for People/Employee <!--<br class="hidden-xs">--><span class="text-default">one location to another.</span></h4>
									 
									<br>
									
									<p>This is a product designed for the organization providing staff transport services (People Logistics) operation to the multiple vendors. The Driver and user module are very user-friendly and the feature like continuous GPRS tracking, Cloud calling and SOS, makes it secure for the commuters. The web admin panel is completely data-centric and makes admin work easy for assigning cab to computers and getting weekly and monthly reports of the drivers.</p>
									
									
									<br>
									
									
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-1-4">
									
									<h4>A beauty salon or beauty parlor (beauty parlour) (or sometimes beauty shop) is an establishment<!--<br class="hidden-xs">--> dealing with cosmetic <span class="text-default">treatments for men and women..</span></h4>
								
									<br>
									
									<p>It’s a one-stop solution for the Beauty Salon, Spa center, Yoga Center, GYM, and massage center. It features appointment booking and scheduling, online Payment gateway, Client management, Offers, and Sales. While the Android-based Admin panel provides an easy but reach people (workforce) management options which help you to run your business on fingertip.</p>
									
									
									<br>
									
									<!--<a class="btn btn-default btn-xs" href="#">Creative</a>
									<a class="btn btn-blue btn-xs" href="#">Inteligent</a>
									<a class="btn btn-green btn-xs" href="#">Smart</a>
									<a class="btn btn-black btn-xs" href="#">Casual</a> -->
										
								</div> 

<!-- tab-pane -->
								<div class="tab-pane fade" id="tab-1-5">
									
									<h4>Cras sit amet maximus augue dolor <br class="hidden-xs"> erat finibus iaculis non. <span class="text-default">Enjoy.</span></h4>
									
									<br>
									
									<p>Praesent ut ipsum congue, elementum diam vitae, porta odio. Etiam porta justo vitae purus viverra, et dapibus est 
									rhoncus. Aenean vehicula maximus eros, eget elementum ipsum suscipit sit amet. Integer tincidunt eros eu euismod 
									ullamcorper. Nullam pharetra sem sit amet consectetur tristique. Sed aliquet ante eros, id porta dui semper sed. Cras 
									sit amet maximus augue. Donec lobortis libero eget justo venenatis.</p>
									
									<p>Morbi dignissim, tortor vitae hendrerit imperdiet, metus nibh blandit mi, eget interdum nibh turpis eget tellus. In 
									facilisis tortor ante, vitae vestibulum augue sodales sagittis suscipit sit amet.</p>
									
									<br>
									
									<a class="btn btn-default btn-xs" href="#">Creative</a>
									<a class="btn btn-blue btn-xs" href="#">Inteligent</a>
									<a class="btn btn-green btn-xs" href="#">Smart</a>
									<a class="btn btn-black btn-xs" href="#">Casual</a>
										
								</div> <!-- tab-pane -->
							</div><!-- tab-content -->
						
						</div><!-- vertical-tabs -->
						
					</div><!-- col -->
					<div class="col-sm-4">
						
						<p><img class="wow fadeInRight" src="images and icons/image.png" alt=""></p>
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<section class="full-section parallax" id="section-2" data-stellar-background-ratio="0.1">
				
				<div class="full-section-shadow-top"></div>
				<div class="full-section-shadow-bottom"></div>
				
				<div class="full-section-container">
					
					<div class="container">
						<div class="row">
							<div class="col-sm-6">
								
								<h3><span class="text-default">Know </span> what you need.</h3>
								
								<p>To know more about our apps and there working  <br class="hidden-sm hidden-xs">process book a demo for free. </p>
								
							</div><!-- col -->
							<div class="col-sm-6 text-right">
								
								<br>
                                <!--<a class="btn btn-default" data-toggle="modal" data-target="#myModal-2">Book your Demo</a>-->
                                <a href="contact-us.php" class="btn btn-default">Book your Demo</a>
								
							</div><!-- col -->
						</div><!-- row -->
					</div><!-- container -->
					
				</div><!-- full-section-container -->
				
			</section><!-- full-section -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>Our work and Achievements</h3>
							<p>Xplotica team has been providing innovative, cost efficient and timely solutions that generate the growth of  <br class="hidden-xs">small and medium-sized businesses globally. </p>
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-5">
						
						<h4>Let your business grow with us.</h4>
						
						<br>
						
						<p>Here in Xplotica IT Solutions, we cater technology. We work on the cutting edge technology and keep our self-updated according to the recent technology changes in the Technical world. We Provide Easy to use and effective solution for Pharmaceutical management system, Corporate Cab management system and School management system. Our Ready to use application for Pharmaceutical, Cab management, Logistic and Education is designed with the consultation with experts of the corresponding industry and are highly appreciated by the users. All the Applications are highly robust and can be enhanced according to the requirement.</p>
						
						
						
					</div><!-- col -->
					<div class="col-sm-7">
						
						<br><br>
						
						<div class="row">
							<div class="col-sm-4">
								
								<div class="counter blue">
										
									<i class="mt-icon-myspace"></i>
									
									<div class="counter-value" data-value="255"></div>
									
									<div class="counter-details">Clients</div>
									
								</div><!-- counter -->
								
							</div><!-- col -->
							<div class="col-sm-4">
								
								<div class="counter default">
										
									<i class="mt-icon-document3"></i>
									
									<div class="counter-value" data-value="1176"></div>
									
									<div class="counter-details">Projects</div>
									
								</div><!-- counter -->
								
							</div><!-- col -->
							<div class="col-sm-4">
								
								<div class="counter green">
										
									<i class="mt-icon-diamond"></i>
									
									<div class="counter-value" data-value="39"></div>
									
									<div class="counter-details">Awards</div>
									
								</div><!-- counter -->
								
							</div><!-- col -->
						</div><!-- row -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			
			<section class="full-section" id="section-3" style="padding-top: 40px;">
				
				<div class="full-section-shadow-top"></div>
				<div class="full-section-shadow-bottom"></div>
				
				<div class="parallax-multilayer">
                	
                    <div class="parallax-layer" data-stellar-ratio="0.3" data-x="5%" data-y="40%"><img src="images/index/multilayer-parallax/image-1.png" alt=""></div>	
					
					<div class="parallax-layer" data-stellar-ratio="0.5" data-x="90%" data-y="10%"><img src="images/index/multilayer-parallax/image-2.png" alt=""></div>
					
					<div class="parallax-layer" data-stellar-ratio="1.7" data-x="75" data-y="50%"><img src="images/index/multilayer-parallax/image-3.png" alt=""></div>
					
				</div><!-- parallax-multilayer -->
				
				<div class="full-section-container">
					
					<div class="container">
						<div class="row">
							<div class="col-sm-12">
								
								<div class="headline">
									
									<h3>What we do best</h3>
									
									
								</div><!-- headline -->
								
							</div><!-- col -->
						</div><!-- row -->
					</div><!-- container -->
					
					<div class="container">
						<div class="row">
							<div class="col-sm-4">
								
								<div class="service-box style-1 default">
										
									<!--<i class="mt-icon-screen1"></i>-->
									<img src="images and icons/Modern Design.png" class="img-responsive">
									<!--<div class="service-box-content">-->
										<div>
										<h6>Modern Design</h6>
										
										<p>Our Dedicated team for UI and UX team works very keenly to improvise the application look according to the latest Industry changes and trends.</p>
										
									</div><!-- service-box-content -->
									
								</div><!-- service-box -->
								
							</div><!-- col -->
							<div class="col-sm-4">
								
								<div class="service-box style-1 blue">
										
									<!--<i class="mt-icon-drop"></i> -->
									<img src="images and icons/User Friendly flow.png" class="img-responsive">
									<!--<div class="service-box-content">-->
										<div>
										<h6>User Friendly flow</h6>
										
										<p>The User Experience team has designed the application flow keeping it user-centric and we keep improvising it according to user feedback and technology changes.</p>
										
									</div><!-- service-box-content -->
									
								</div><!-- service-box -->
								
							</div><!-- col -->
							<div class="col-sm-4">
								
								<div class="service-box style-1 green">
										
									<!--<i class="mt-icon-smartphone1"></i>-->
									<img src="images and icons/Responsive Layout.png" class="img-responsive">
									<!--<div class="service-box-content">-->
										<div>
										<h6>Responsive Layout</h6>
										
										<p>The Web, Android, and IOS apps have been developed for all types of devices ranging from mobile, Tab, Small, medium and large screen desktop or laptop.
</p>
										
									</div><!-- service-box-content -->
									
								</div><!-- service-box -->
								
							</div><!-- col -->
						</div><!-- row -->
					</div><!-- container -->
					
					<div class="container">
						<div class="row" style="text-align:justify;">
							<div class="col-sm-4">
								
								<div class="service-box style-1 blue">
										
									<!--<i class="mt-icon-wifi2"></i>-->
									<img src="images and icons/Easy to Customize.png" class="img-responsive">
									<!--<div class="service-box-content">-->
										<div>
										<h6>Easy to customize</h6>
										
										<p>The process of settings in the application are very simple without any complications the user can customize the app easily.
</p>
										
									</div><!-- service-box-content -->
									
								</div><!-- service-box -->
								
							</div><!-- col -->
							<div class="col-sm-4">
								
								<div class="service-box style-1 green">
										
									<!--<i class="mt-icon-notepad"></i> -->
									<img src="images and icons/Full Documentation.png" class="img-responsive">
									<!--<div class="service-box-content">-->
										<div>
										<h6>Full documentation</h6>
										
										<p>Mobile Apps leverages the functionality of App development to add sign-in, push notifications, and data sync to your mobile app. Connect your app to enterprise systems and on-premises resources. Scale your app to millions of customers across multiple geographies.</p>
										
									</div><!-- service-box-content -->
									
								</div><!-- service-box -->
								
							</div><!-- col -->
							<div class="col-sm-4">
								
								<div class="service-box style-1 default">
										
									<!--<i class="mt-icon-code"></i>-->
									<img src="images and icons/Light and Fast app.png" class="img-responsive">
									<!--<div class="service-box-content">-->
										<div>
										<h6>Light &amp; fast</h6>
										
										<p>The app will not take the much space to install in the device. If you open the app, the data is already loaded and ready to go.
</p>
										
									</div><!-- service-box-content -->
									
								</div><!-- service-box -->
								
							</div><!-- col -->
						</div><!-- row -->
					</div><!-- container -->
					
					<div class="container">
						<div class="row">
							<div class="col-sm-4">
								
								<div class="service-box style-1 green">
										
									<!--<i class="mt-icon-levels"></i> -->
									<img src="images and icons/Data Centric Admin panel.png" class="img-responsive">
									<!--<div class="service-box-content">-->
										<div>
										<h6>Data Centric Admin panel</h6>
										
						<p>The admin panel is connected with the data-centric device which is helpful to get the lost data in the admin panel from the database. 
</p>
										
									</div><!-- service-box-content -->
									
								</div><!-- service-box -->
								
							</div><!-- col -->
							<div class="col-sm-4">
								
								<div class="service-box style-1 default">
										
									<!--<i class="mt-icon-stars"></i>-->
									<img src="images and icons/Highly optimized database.png" class="img-responsive">
									<!--<div class="service-box-content">-->
										<div>
										<h6>Highly optimized database</h6>
										
										<p>The database is highly optimized with the double layer protective shield for the security purpose of database system 
</p>
										
									</div><!-- service-box-content -->
									
								</div><!-- service-box -->
								
							</div><!-- col -->
							<div class="col-sm-4">
								
								<div class="service-box style-1 blue">
										
									<!--<i class="mt-icon-linegraphic"></i>-->
									<img src="images and icons/Client Centric reports.png" class="img-responsive">
									<!--<div class="service-box-content">-->
										<div>
										<h6>Client Centric reports</h6>
										
										<p>Some of the futures of app can be changed according to the client requirements as the clients are our main priority.
</p>
										
									</div><!-- service-box-content -->
									
								</div><!-- service-box -->
								
							</div><!-- col -->
						</div><!-- row -->
					</div><!-- container -->
					
					<!--<div class="container">
						<div class="row">
							<div class="col-sm-12 text-center">
								
								<a class="btn btn-default" href="services.html">View all services</a>
								
							</div>
						</div>
					</div>--> <!--  -->
					
				</div><!-- full-section-container -->
				
			</section><!-- full-section -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>Take a look at our portfolio</h3>
							<!--<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem</p>-->
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<!-- container -->
         <div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="horizontal-tabs pfoliotab">
						<div class="row">
                            <div class="col-md-3"></div>
                            <div class="col-md-6">
                            <ul class="nav nav-tabs" style="margin-left: 12%;">
								<li class="active"><a href="#tab-3-1" data-toggle="tab">Digiedu</a></li>
								<li><a href="#tab-3-2" data-toggle="tab">Pharmaceutical </a></li>
								<li><a href="#tab-3-3" data-toggle="tab">Transportation </a></li>
								<!--<li><a href="#tab-3-4" data-toggle="tab">Drug Discovery Partners</a></li>-->
							</ul>
                            </div>
                            <div class="col-md-3"></div>
							 
                            </div>
						
							 <div class="tab-content">
								<div class="tab-pane fade in active" id="tab-3-1">
									
									<div class="row">
									 <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/1.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/1.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
                    <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/2.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/2.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
                    <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/3.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/3.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
                    <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/4.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/4.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
									</div><!-- row -->
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-3-2">
									
									<div class="row">
									 <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/5.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/5.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
                     <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/6.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/5.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
                     <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/7.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/7.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
                     <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/8.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/8.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
									</div><!-- row -->
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-3-3">
									
									<div class="row">
										 <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/magic%20travels.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/magic%20travels.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
                    <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/road%20assist%20club.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/road%20assist%20club.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
                     <div class="col-md-3">
                    <div class="portfolio-item">
                                   
							
									<div class="portfolio-item-thumbnail">
										
										<img src="images/portfolio/transt%20oak.jpg" alt="">
										
										<div class="portfolio-item-hover">
											
											<a class="fancybox zoom-action" data-fancybox-group="portfolio" href="images/portfolio/transt%20oak.jpg"><i class="mt-icon-expand2"></i></a>
											
										</div><!-- portfolio-item-hover -->
										
									</div><!-- portfolio-item-thumbnail -->
									
								</div>
                    </div>
									</div><!-- row -->
										
								</div><!-- tab-pane -->
								<div class="tab-pane fade" id="tab-3-4">
									
									<div class="row">
									<!-- col -->
									</div><!-- row -->
										
								</div><!-- tab-pane -->
							</div><!-- tab-content -->
						
						</div><!-- horizontal-tabs -->
						
					</div><!-- col -->
				</div><!-- row -->
      </div>
      <div class="container">
						<div class="row">
							<div class="col-sm-6">
							</div><!-- col -->
							<div class="col-sm-6 text-right">
						
								<a class="btn btn-default" href="portfolio.php">More Details</a>
								
							</div><!-- col -->
						</div><!-- row -->
					</div>
             
			
       <!-- PAGE CONTENT END -->
		<div class="container">

    <div class="modal fade" id="myModal-2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel-2">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content" style="margin-top: 28%;">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel-2">Enter your Details</h4>
                </div>

                <div class="modal-body">
                   <form id="aboutus_add" class="form-horizontal mb-lg" novalidate="novalidate">
 
					<div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-user" style="color:#3badad"></i></span>
						<input id="Text" type="text" class="form-control modal-style" name="name" placeholder="Name" pattern="[a-zA-Z0]+" required="">
					</div>
					<div class="input-group top">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-phone" style="color:#3badad"></i></span>
						<input id="mobile" type="number" class="form-control modal-style" name="phone" placeholder="Phone number" pattern="^\d{10}$"  required="">
					</div>
							
					<div class="input-group top">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope" style="color:#3badad"></i></span>
						<input id="email" type="text" class="form-control modal-style" name="email" placeholder="Email" required="">
					</div>
				<input type ="hidden" class='couponTest' name="adminemail">
					<div class="input-group top">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-hand-right" style="color:#3badad"></i></span>
					<select class="form-control modal-style" id="sel1" name="option" onchange="select_locality()" required>
                     <option id="demo">Select demo type</option>
                    <option name="digiedu" value="digiedu">Digiedu</option>
                     <option name="phamarc" value="phamarc">Phamarc</option>
                    <option name="triptrack" value="triptracs">Triptracs</option>
                    </select>
					</div>
					<div class="form-group top" style="margin-left: 0px;margin-right: 0px;">
					  <textarea class="form-control modal-style" rows="4" id="comment" placeholder="Message" name="message" required=""></textarea>
					</div>
					
					
                        <center>
									<div class="form-group">
															<div class="col-md-3">
															</div>
															<div class="col-md-9">
															<div class="alert alert-success" id="alert_success_tech" style="display:none"> 
																<strong>Success!</strong>&nbsp;Successfully Submitted
															  </div>
															  <div class="alert alert-danger" id="alert_fail_tech" style="display:none">
																<strong>Failed!</strong>&nbsp;Something went wrong
															  </div>
															</div>
														</div>
														
                            <button type="button" class="btn btn-success top sunanda"  id="aboutus_add_btn" style="background-color: #fe5e3e!important">Submit</button>
                        </center>
                    </form>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <!--<button type="button" class="btn btn-dialog">Ok</button>-->
                </div>
            </div>
            <!-- modal-content -->
        </div>
        <!-- modal-dialog -->
    </div>
    <!-- modal -->


</div><!-- container -->
<script>
function select_locality()
{
	var x = $("#sel1").val(); 
	$.ajax({
	     type: "POST",
		 url:'getemail.php',
	     data: "x="+x,
	      success: function(data) { 
		 // alert(data);
		   var dataz = $.trim(data);
		    $('.coupon').html(dataz);
			   $('.couponTest').val(dataz);
	     }
	   });
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="jquery_validation/extension.css">
<script src="jquery_validation/validate.js"></script>
<script>
  $(document).ready(function(){
			$('.sunanda').click(function(){
			//alert("hai");
				if($('#aboutus_add').valid()){
					var formData = new FormData();
					var formData = new FormData($('#aboutus_add')[0]);
						   $.ajax({
							 type:'POST',
							 url :"mailfunction.php",
							 data: formData,
							 cache: false,
							contentType: false,
							processData: false,
							 success: function(data) {
								//var res=jQuery.parseJSON(data);// convert the json
								console.log(data);
								if(data == 'Success'){
									$("#alert_success_tech").show();
									setTimeout(function () {
									window.location.href = "index.php"; 
									}, 2000); //will call the function after 2 secs.
								}else if(data == 'Error'){
									$("#alert_fail_tech").show();
									setTimeout(function () {
									window.location.href = "index.php"; 
									}, 2000); //will call the function after 2 secs.
								}
							   },
							 error:function(exception){
							 alert('Exeption:'+exception);
							}
							});
					return false;
				}
			});
		});
		
  </script>
<?php include("footer.php"); ?>
