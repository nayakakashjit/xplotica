<!doctype html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    
    <title>DigiEdu Best Education Management App | Xplotica IT Solutions</title>
     <meta name="title" content="DigiEdu Best Education Management App | Xplotica IT Solutions" />
     <meta name="description" content="“DigiEdu” is an android application which provides a complete software solution for the school management. Our easy to use and user-friendly modules"/>
    <meta name= "keywords" content= "School Management System" />
    <meta name= "keywords" content= "school administration software,school management software demo,school management system software,online school management system,student management system,online school management software,education management software,software for school management,student management software,best school management software,school accounting software,software for schools,school attendance software,institute management software,school information system,school management software,school management information system,school database software,school management web application,school management application,school management app, private school management software,school administrative software,online school software,school registration software,school management website" />
    
    <!-- FAVICON AND APPLE TOUCH  --> 
    <link rel="shortcut icon" href="favicon-180x180.png">  
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="favicon-180x180.png">
    
    <!-- FONTS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,300italic,300,500,500italic,700,700italic">
    
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="property/bootstrap/css/bootstrap.min.css"> 
    
    <!-- MT ICONS FONT -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="property/fonts/mt-icons/mt-icons.css">
    
    <!-- FANCYBOX -->
    <link rel="stylesheet" href="property/plugins/fancybox/jquery.fancybox.css">
	
	<!-- REVOLUTION SLIDER -->
    <link rel="stylesheet" href="property/plugins/revolutionslider/css/settings.css">
    
    <!-- OWL Carousel -->
    <link rel="stylesheet" href="property/plugins/owl-carousel/owl.carousel.css">
	<link rel="stylesheet" href="property/plugins/owl-carousel/owl.transitions.css">
	
	<!-- YOUTUBE PLAYER -->
    <link rel="stylesheet" href="property/plugins/ytplayer/css/jquery.mb.YTPlayer.min.css">
    
    <!-- ANIMATIONS -->
    <link rel="stylesheet" href="property/plugins/animations/animate.min.css">
    
    <!-- CUSTOM & PAGES STYLE -->
    <link rel="stylesheet" href="property/css/custom.css">
    <link rel="stylesheet" href="property/css/pages-style.css">
    
    <!-- STYLE SWITCHER -->
  <link rel="stylesheet" href="property/plugins/style-switcher/style-switcher.css">
    
    <!-- ALTERNATIVE STYLES -->
    <link rel="stylesheet" href="#" data-style="styles">
    

</head>
    <style>      
        input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    -moz-appearance:textfield;
}

a {
  text-decoration: none;
}
    </style>

<body>

	<div id="page-wrapper">
        
		<!-- HEADER -->
		<header>	
			
			<div id="header-top">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-8">
						
							<div class="widget widget-contact">
								
								<ul>
									<li>    
										<i class="mt-icon-telephone1"></i>
										<span class="hidden-xs" style="color: #fff;" style="text-decoration:none">+91 8867700428</span>
										<a class="visible-xs-inline" href="tel:+91 8867700428" style="text-decoration:none">+91 8867700428</a>
									</li>
									<li>
										<i class="mt-icon-mail"></i>
										<a href="#" style="text-decoration: none;">contact@xplotica.com</a>
									</li>
								</ul>
								
							</div><!-- widget-contact -->
							
						</div><!-- col -->
						<div class="col-sm-4">
						<div class="widget widget-contact">
								
								<ul style="text-align: right;margin-right: 3%;">
									<li>
									        <i class="mt-icon-telephone1"></i>
										<a href="support-xplotica.php">Support</a>
									</li>
									<li>
										<i class="fa fa-user" aria-hidden="true"></i>
										<a href="partner-xplotica.php">Partner</a>
									</li>
								
                                    <li>
										<i class="fa fa-rss" aria-hidden="true"></i>
										<a target="_blank" href="http://xplotica.com/blog">Blog</a>
									</li>
								</ul>
								
							</div>
							
							<!--<div class="widget widget-social">
												
								<div class="social-media">
								   <a class="facebook" href="#"><i class="mt-icon-facebook"></i></a>
									<a class="twitter" href="#"><i class="mt-icon-twitter"></i></a>
									<a class="google" href="#"><i class="mt-icon-google-plus"></i></a>
									<a class="pinterest" href="#"><i class="mt-icon-pinterest"></i></a>
									<a class="youtube" href="#"><i class="mt-icon-youtube-play"></i></a>                                    
								</div>
								
							</div>--><!-- widget-social -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->  
				
			</div><!-- header-top -->
			
			<div id="header">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							
							<!-- LOGO -->
							<div id="logo" style="margin-bottom: 3px;margin-top:3px;">
								<a href="index.php">
									<img src="property/images/logo xplotica.png" alt="">
								</a>
							</div><!-- logo -->
							
						</div><!-- col -->
						<div class="col-sm-10">
							
							<!-- MENU --> 
							<nav>
							
								<a id="mobile-menu-button" href="#"><i class="mt-icon-menu"></i></a>
												 
								<ul class="menu clearfix" id="menu">
									<li class="active">
										<a href="index.php" id="pd"><i class="mt-icon-home" style="font-weight:700;font-size: 16px;"></i></a>
									</li>
									<li>
										<a href="digi-edu.php" id="pd">Digiedu</a>
										
									</li>
									<!--<li class="dropdown">
												<a href="#" id="pd">Products</a>
												<ul>
													<li><a href="#">Trywis</a></li>
													<li><a href="#">Digiedu</a></li>
													<li><a href="#">Salon search</a></li>
													<li><a href="#">Pharmaceutical</a></li>
													<li><a href="#">Transportation</a></li>
												</ul>
											</li>-->
									<li>
										<a href="phamarc.php" id="pd">PHAMARC</a>
										
									</li>
									<li>
										<a href="transportation.php" id="pd">TRIPTRACS</a>
										
									</li>
									<!--<li class="dropdown">
										<a href="salon_search.php" id="pd">Salon</a>
										
									</li>-->
									
									<li class="dropdown">
												<a href="#" id="pd">INDUSTRY</a>
												<ul>
													
													<!--<li><a href="salon_search_industry.php">Salon</a></li> -->	
													<li><a href="Education-industry.php">Education</a></li>
													<li><a href="Pharmaceutical-industry.php">Pharmaceutical</a></li>
													<li><a href="transportation-industry.php">Transportation</a></li>
													
												</ul>
											</li>
											<li>
										<a href="contact-us.php" id="pd">CONTACT US</a>
										
									</li>
									
								</ul>
							
							</nav>
						
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->    
						
			</div><!-- header -->
		
		</header><!-- HEADER -->


   <link rel="stylesheet" href="property/css/custom_modal.css">
<style>
.top{margin-top: 4%;}
.modal-style{border-radius: 0px;}
..input-group-addon {
               color: #009688 !important;
}
</style>
  <div id="page-content"> <!--PAGE CONTENT -->
      <div id="page-header">  
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            
                            <h4>Welcome to DigiEdu</h4>
                            
                        </div><!-- col -->
                    </div><!-- row -->
                </div><!-- container -->    
            </div><!-- page-header -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>About DigiEdu</h3>
							
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-8">
						
						<div class="row">
							<div class="col-sm-6">
								
								
								
								<p style="text-align:justify">“DigiEdu” is an android application which provides a complete software solution for the school management. Our easy to use and user-friendly modules are designed to reduce paperwork. The automated feature has been designed to reduce the human interaction thus making processing error-free. </p>
								
							</div><!-- col -->
							<div class="col-sm-6">
								
								<p>The application is having Android interface for Parent and teacher modules which contain Diary, attendance and Chat messaging functionality to make the interaction with teachers prompt and easy.</p>
								
								
								
							</div><!-- col -->
						</div><!-- row -->
						
						<br>
						<h4>It has various kinds of modules</h4>
						<ul class="arrow-list">
							<li class="text-uppercase"><strong> Teacher Module</strong></li>
							<li class="text-uppercase"><strong> Parents Module</strong></li>
							<li class="text-uppercase"><strong> Admin Module</strong></li>
							<li class="text-uppercase"><strong> Sub-Admin Module</strong></li>
						</ul>
						
					</div><!-- col -->
					<div class="col-sm-4">
						
						<p><img class="wow fadeInRight" src="images/services/image-3.jpg" alt=""></p>
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<section class="full-section dark-section parallax" id="section-17" data-stellar-background-ratio="0.1" style="margin-top: 30px;">
				
				<div class="full-section-overlay-color"></div>
				
				<div class="full-section-container">
				
					<div class="container">
						<div class="row">
							<div class="col-sm-12">
								
								<h3 class="text-center"><strong>Sometimes <span class="text-default">we win</span>, sometimes <span class="text-default">we 
								learn</span>.</strong></h3>
								
							</div><!-- col -->
						</div><!-- row -->
					</div><!-- container -->
					
					<br><br>
					
					<div class="container">
						<div class="row">
							<div class="col-sm-3">
								
								<div class="pie-chart-container">
											
									<div class="pie-chart blue" data-percent="95" data-size="170" data-line-width="4" data-track-color="transparent" data-bar-color="#00d2ed">
										
										<i class="mt-icon-myspace"></i>
										
										<div class="pie-chart-details">
											
											<h1><span class="value"></span>%</h1>
											<h6>Happy Clients</h6>
										
										</div><!-- pie-chart-percent -->													
									
									</div><!-- pie-chart -->
								
								</div><!-- pie-chart-container -->
								
							</div><!-- col -->
							<div class="col-sm-3">
								
								<div class="pie-chart-container">
											
									<div class="pie-chart default" data-percent="75" data-size="170" data-line-width="4" data-track-color="transparent" data-bar-color="#fe5e3e">
										
										<i class="mt-icon-document3"></i>
										
										<div class="pie-chart-details">
											
											<h1><span class="value"></span>%</h1>
											<h6>Work</h6>
										
										</div><!-- pie-chart-percent -->													
									
									</div><!-- pie-chart -->
								
								</div><!-- pie-chart-container -->
								
							</div><!-- col -->
							<div class="col-sm-3">
								
								<div class="pie-chart-container">
											
									<div class="pie-chart green" data-percent="58" data-size="170" data-line-width="4" data-track-color="transparent" data-bar-color="#00e095">
										
										<i class="mt-icon-speechbubble1"></i>
										
										<div class="pie-chart-details">
											
											<h1><span class="value"></span>%</h1>
											<h6>Comunication</h6>
										
										</div><!-- pie-chart-percent -->													
									
									</div><!-- pie-chart -->
								
								</div><!-- pie-chart-container -->
								
							</div><!-- col -->
							<div class="col-sm-3">
								
								<div class="pie-chart-container">
											
									<div class="pie-chart default" data-percent="99" data-size="170" data-line-width="4" data-track-color="transparent" data-bar-color="#fe5e3e">
										
										<i class="mt-icon-trophy"></i>
										
										<div class="pie-chart-details">
											
											<h1><span class="value"></span>%</h1>
											<h6>Design</h6>
										
										</div><!-- pie-chart-percent -->													
									
									</div><!-- pie-chart -->
								
								</div><!-- pie-chart-container -->
								
							</div><!-- col -->
						</div><!-- row -->
					</div><!-- container -->

					
				</div><!-- full-section-container -->
				
			</section><!-- full-section -->
      
               
			
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="headline">
							
							<h3>Features of DigiEdu</h3>
							<p>DigiEdu had the some of the features like the Diary, Attendance, Messaging, Gallery, Events, Transport, etc.</p>
							
						</div><!-- headline -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
			
			<div class="container">
				<div class="row">
					<div class="col-sm-5">
						
						<div class="service-box style-2 icon-right wow fadeInLeft">
										
							<i class="mt-icon-screen1"></i>
							
							<div class="service-box-content">
								
								<h6>Diary</h6>
								
								<p>DigiEdu App has working dairy forum where students learn and practice.
This is a total course of events perspective of educational, expenses, comes about related data being sent by the school all the time.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
						<div class="service-box style-2 icon-right wow fadeInLeft">
								<i class="mt-icon-document3"></i>		
							<!--<i class="mt-icon-picture"></i>-->
							
							<div class="service-box-content">
								
								<h6>Attendance</h6>
								
								<p>Positive way to deal with non-appearance students which applies standards of conduct alteration to accomplish enhanced participation at work.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
						<div class="service-box style-2 icon-right wow fadeInLeft">
										
							<i class="mt-icon-word"></i>
							
							<div class="service-box-content">
								
								<h6>Homework</h6>
								
								<p>This feature is useful to know the work given to the students in the class to do after the school hours every day.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
					<div class="col-sm-2">
						
						<br><br class="hidden-xs">
						
						<p class="text-center"><img class="wow pulse" src="images/services/image-4.png" alt=""></p>
						
						<br><br>
						
					</div><!-- col -->
					<div class="col-sm-5">
						
						<div class="service-box style-2 icon-left wow fadeInRight">
										
							<i class="mt-icon-document3"></i>
							
							<div class="service-box-content">
								
								<h6>Messaging</h6>
								
								<p>It is a special feature available in the DigiEdu school management app which allows the teacher to know more about the parents and vice-versa through the chat.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
						<div class="service-box style-2 icon-left wow fadeInRight">
										
							<!--<i class="mt-icon-smartphone1"></i>-->
                            <i class="mt-icon-picture"></i>
							
							<div class="service-box-content">
								
								<h6>Gallery</h6>
								
								<p>Photographs - Create boundless collections and photographs for all the fun youngsters have in your school. Be it that extraordinary outing or occasions like the  annual function, Republic day, Independence Day and the NCC camp held in the school.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
						<div class="service-box style-2 icon-left wow fadeInRight">
										
							<i class="mt-icon-stars"></i>
							
							<div class="service-box-content">
								
								<h6>Events</h6>
								
								<p>DigiEdu App will send you the notifications about events like parent-teacher meeting (PTM), annual function, republic day, Independence Day, etc. And give you the updates about the events.</p>
								
							</div><!-- service-box-content -->
							
						</div><!-- service-box -->
						
					</div><!-- col -->
				</div><!-- row -->
			</div><!-- container -->
     
			<div class="container">
						<div class="row">
							<div class="col-sm-8">
                               
							</div><!-- col -->
                             <div class="col-sm-2 text-right">
							
                            <!--<a class="btn btn-default" data-toggle="modal" data-target="#myModal-2">Book your Demo</a>-->
                                <a href="contact-us.php" class="btn btn-default">Book your Demo</a>
								
							</div>
							<div class="col-sm-2 text-right">
						
								<a class="btn btn-default" href="http://digiedu.online" target="_blank">More Details</a>
								
							</div><!-- col -->
						</div><!-- row -->
					</div>
      
								
							</div>
						</div>
					</div>
					
				</div>
				
			</section>
			
			
			
			<div class="container">

    <!--<div class="text-center">
		<button type="button" class="btn btn-demo" data-toggle="modal" data-target="#myModal-2">
			Dialog - Normal
		</button>
	</div>-->



    <div class="modal fade" id="myModal-2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel-2">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content" style="margin-top: 28%;">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel-2">Enter your Details</h4>
                </div>

                <div class="modal-body">
                    <form id="myform" action="mailcareerdigiedu.php" method="POST">
 
					<div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-user" style="color:#3badad"></i></span>
						<input id="Text" type="text" class="form-control modal-style" name="name" placeholder="Name" pattern="[a-zA-Z0]+" required="">
					</div>
					<div class="input-group top">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-phone" style="color:#3badad"></i></span>
						<input id="Text" type="number" class="form-control modal-style" name="phone" placeholder="Phone number" pattern="^\d{10}$"  required="">
					</div>
							
					<div class="input-group top">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope" style="color:#3badad"></i></span>
						<input id="email" type="text" class="form-control modal-style" name="email" placeholder="Email" required="">
					</div>
					<div class="form-group top">
					  <textarea class="form-control modal-style" rows="4" id="comment" placeholder="Message" name="message" required=""></textarea>
					</div>
					
					
                        <center>
                            <button class="btn btn-success top" type="submit" id="btn_submit" style="background-color: #fe5e3e!important">Submit</button>
                        </center>
                    </form>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <!--<button type="button" class="btn btn-dialog">Ok</button>-->
                </div>
            </div>
            <!-- modal-content -->
        </div>
        <!-- modal-dialog -->
    </div>
    <!-- modal -->


</div><!-- container -->

<?php include("footer.php"); ?>