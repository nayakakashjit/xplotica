<!doctype html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    
    <title>Support - Xplotica IT Solution</title>
    <meta name="title" content="Support - Xplotica IT Solution"/>
    <meta name="description" content="Xplotica care has a dedicated technical support team who is readily available to support and provide its users maximum assistance."/>
    <meta name="description" content="Xplotica care has a dedicated technical support team who is readily available to support and provide its users maximum assistance."/>
    <meta name= "keywords" content= "Xplotica Customer care" />
    <meta name= "keywords" content= "Xplotica Customer care,Xplotica Customer service,Xplotica Customer support,About Xplotica IT Solutions Pvt. Ltd.,,Xplotica,Xplotica IT Solutions,Xplotica IT Solutions Pvt. Ltd.,,Xplotica,Xplotica IT Solutions,School Management System,Pharmaceutical product management Application,Transportation Management System,School Management System Application,Pharmaceutical Product Management System,Transportation Management System" />
    
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
<link href="css/mdb.min.css" rel="stylesheet">
    <!-- FAVICON AND APPLE TOUCH  --> 
    <link rel="shortcut icon" href="favicon-180x180.png">  
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="favicon-180x180.png">
    
    <!-- FONTS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,300italic,300,500,500italic,700,700italic">
    
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="property/bootstrap/css/bootstrap.min.css"> 
    
    <!-- MT ICONS FONT -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="property/fonts/mt-icons/mt-icons.css">
    
    <!-- FANCYBOX -->
    <link rel="stylesheet" href="property/plugins/fancybox/jquery.fancybox.css">
	
	<!-- REVOLUTION SLIDER -->
    <link rel="stylesheet" href="property/plugins/revolutionslider/css/settings.css">
    
    <!-- OWL Carousel -->
    <link rel="stylesheet" href="property/plugins/owl-carousel/owl.carousel.css">
	<link rel="stylesheet" href="property/plugins/owl-carousel/owl.transitions.css">
	
	<!-- YOUTUBE PLAYER -->
    <link rel="stylesheet" href="property/plugins/ytplayer/css/jquery.mb.YTPlayer.min.css">
    
    <!-- ANIMATIONS -->
    <link rel="stylesheet" href="property/plugins/animations/animate.min.css">
    
    <!-- CUSTOM & PAGES STYLE -->
    <link rel="stylesheet" href="property/css/custom.css">
    <link rel="stylesheet" href="property/css/pages-style.css">
    
    <!-- STYLE SWITCHER -->
  <link rel="stylesheet" href="property/plugins/style-switcher/style-switcher.css">
    
    <!-- ALTERNATIVE STYLES -->
    <link rel="stylesheet" href="#" data-style="styles">
    

</head>
   

<body>

	<div id="page-wrapper">
        
		<!-- HEADER -->
		<header>	
			
			<div id="header-top">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-8">
						
							<div class="widget widget-contact">
								
								<ul>
									<li>    
										<i class="mt-icon-telephone1"></i>
										<span class="hidden-xs" style="color: #fff;" style="text-decoration:none">+91 8867700428</span>
										<a class="visible-xs-inline" href="tel:+91 8867700428" style="text-decoration:none">+91 8867700428</a>
									</li>
									<li>
										<i class="mt-icon-mail"></i>
										<a href="#" style="text-decoration: none;">contact@xplotica.com</a>
									</li>
								</ul>
								
							</div><!-- widget-contact -->
							
						</div><!-- col -->
						<div class="col-sm-4">
						<div class="widget widget-contact">
								
								<ul style="text-align: right;margin-right: 3%;">
									<li>
									        <i class="mt-icon-telephone1"></i>
										<a href="support-xplotica.php">Support</a>
									</li>
									<li>
										<i class="fa fa-user" aria-hidden="true"></i>
										<a href="partner-xplotica.php">Partner</a>
									</li>
								
                                    <li>
										<i class="fa fa-rss" aria-hidden="true"></i>
										<a target="_blank" href="http://xplotica.com/blog">Blog</a>
									</li>
								</ul>
								
							</div>
							
							<!--<div class="widget widget-social">
												
								<div class="social-media">
								   <a class="facebook" href="#"><i class="mt-icon-facebook"></i></a>
									<a class="twitter" href="#"><i class="mt-icon-twitter"></i></a>
									<a class="google" href="#"><i class="mt-icon-google-plus"></i></a>
									<a class="pinterest" href="#"><i class="mt-icon-pinterest"></i></a>
									<a class="youtube" href="#"><i class="mt-icon-youtube-play"></i></a>                                    
								</div>
								
							</div>--><!-- widget-social -->
							
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->  
				
			</div><!-- header-top -->
			
			<div id="header">
				
				<div class="container">
					<div class="row">
						<div class="col-sm-2">
							
							<!-- LOGO -->
							<div id="logo" style="margin-bottom: 3px;margin-top:3px;">
								<a href="index.php">
									<img src="property/images/logo xplotica.png" alt="">
								</a>
							</div><!-- logo -->
							
						</div><!-- col -->
						<div class="col-sm-10">
							
							<!-- MENU --> 
							<nav>
							
								<a id="mobile-menu-button" href="#"><i class="mt-icon-menu"></i></a>
												 
								<ul class="menu clearfix" id="menu">
									<li class="active">
										<a href="index.php" id="pd"><i class="mt-icon-home" style="font-weight:700;font-size: 16px;"></i></a>
									</li>
									<li>
										<a href="digi-edu.php" id="pd">Digiedu</a>
										
									</li>
									<!--<li class="dropdown">
												<a href="#" id="pd">Products</a>
												<ul>
													<li><a href="#">Trywis</a></li>
													<li><a href="#">Digiedu</a></li>
													<li><a href="#">Salon search</a></li>
													<li><a href="#">Pharmaceutical</a></li>
													<li><a href="#">Transportation</a></li>
												</ul>
											</li>-->
									<li>
										<a href="phamarc.php" id="pd">PHAMARC</a>
										
									</li>
									<li>
										<a href="transportation.php" id="pd">TRIPTRACS</a>
										
									</li>
									<!--<li class="dropdown">
										<a href="salon_search.php" id="pd">Salon</a>
										
									</li>-->
									
									<li class="dropdown">
												<a href="#" id="pd">INDUSTRY</a>
												<ul>
													
													<!--<li><a href="salon_search_industry.php">Salon</a></li> -->	
													<li><a href="Education-industry.php">Education</a></li>
													<li><a href="Pharmaceutical-industry.php">Pharmaceutical</a></li>
													<li><a href="transportation-industry.php">Transportation</a></li>
													
												</ul>
											</li>
											<li>
										<a href="contact-us.php" id="pd">CONTACT US</a>
										
									</li>
									
								</ul>
							
							</nav>
						
						</div><!-- col -->
					</div><!-- row -->
				</div><!-- container -->    
						
			</div><!-- header -->
		
		</header><!-- HEADER -->

<style>
		#about {
		min-height:320px;
		background-image: url(images/suport/s2.jpg);
		background-size: cover;
	}
	#colr{color:#FE5E3E;}
    
    .breadcrumbs a {
    color: #C33;
    background: url(images/suport/red-arrow.png) no-repeat right 7px;
    padding-right: 20px;
    margin-right: 10px;
}
    .content-box {
    float: left;
    margin: 0 0 20px 0;
    padding: 10px 35px 10px 0;
    border-right: 1px solid #e5e5e5;
    width: 100%;
}
    .content-box h2.heading {
    margin-bottom: 20px;
}
    .content-box h2 {
    font-size: 26px;
    margin: 10px 0 6px;
    color: #508f86;
}
    .left-border {
    border-left: 5px solid #FE5E3E;
    padding-left: 20px;
}
    .right-content {
    width: 100%;
    margin-top: 10px;
}
    .right-content p{
            margin: 0 0 10px;
    }
    .section_title_line4 {
    width: 100%;
    float: left;
    height: 3px;
    padding: 0px;
    margin: 5px auto;
    text-align: center;
    background: url(images/suport/section_title_line4.png) no-repeat;
}

	input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button { 
  -webkit-appearance: none; 
  margin: 0; 
}
</style>
 <style>      
        input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    -moz-appearance:textfield;
}

a {
  text-decoration: none;
}
    </style>

  <div id="page-content-fluid">
	<div id="about">
        <div class="row">
             <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12"></div>
            <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                <br><br><br><br><br>
                <h3>We offer you a <span id="colr">single point</span> of contact to make the contact to make the entire operation
                    <span id="colr"> easy to manage and grow</span></h3>         
            </div>
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <center> <h4>For Support</h4></center>
                   <form id="myform" action="mailcareersupport.php" method="POST">
    <div class="md-form">
	  <i class="fa fa-user prefix"></i>
	  <input type="text" id="name" name="name"  maxlength="20"  class="form-control" required="" data-msg-required="Please Enter a valid Name" style="margin-bottom:25px;">
	  <label>NAME<span class="star">*</span></label>
	</div>
    
    <div class="md-form">
	  <i class="fa fa-envelope prefix"></i>
	  <input type="email" id="email" name="email" class="form-control" required="" data-msg-required="Please Enter a valid Email" style="margin-bottom:25px;">
	  <label>EMAIL<span class="star">*</span></label>
	</div>
		
	<div class="md-form">
	  <i class="fa fa-phone prefix"></i>
	  <input type="number" id="phone" name="phone" minlength="10" maxlength="10"  class="form-control"  required="" data-msg-required="Please Enter a 10 digit Number" style="margin-bottom:25px;"> 
	  <label>PHONE<span class="star">*</span></label>
	</div>
		
	<div class="md-form">
	  <i class="fa fa-pencil prefix"></i>
	  <textarea type="text" id="message" name="message" class="md-textarea"  required=""  data-msg-required="Please Enter Your Message" style="margin-bottom:25px;width: 100%;"></textarea>
	  <label>MESSAGE</label>
	</div>
      <center><button class="btn btn-success" type="submit"  id="btn_submit" style="background-color: #fe5e3e!important">Submit</button></center>
     
</form>             
            </div>
			  <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12"></div>
        </div>
        </div>

   </div>   <!-- PAGE CONTENT END -->
<div class="breadcrumbs" style="    background:#fff;">
        <div class="container">
            <a href="http://xplotica.com/">Home</a> <strong>Xplotica Care</strong>
        </div>
    </div>

<div class="container"> 
    	<div class="row">
      		<div class="col-md-8">
            	<div class="content-box">
      				<h2 class="heading">Xplotica Care</h2>
      				<p class="left-border" style="text-align:justify;">Xplotica care has a dedicated technical support team who  is readily available to support and provide its users maximum assistance. Our diverse and highly skilled global workforce consists of 100+ employees providing maximum support to the customers as well as to the partners regarding software related issues and queries. </p>    
                    <p style="text-align:justify;">Firstly, an Agent takes the call of the customer and provides them a solution accordingly. If the customer has been provided a solution or their query has been resolved then a message will be triggered to them for the purpose of giving feedback for the last call. <br><br>
If the customer is dissatisfied then the Customer will give the Miss Call on the Xplotica Care number then Escalation desk will handle the customer issue. The Escalation Desk will check the customer data and provide the solution accordingly to the customer concern &amp; if issue will resolve then again Thank you message will be triggered to the customer for feedback (solution)</p>
					       
				</div>    
			</div>
                  
            <div class="col-md-4">                
                <div class="right-content">
                    <div class="adress">
                    	<h4><strong>For Technical Support/Assistance</strong></h4>
    					<div class="section_title_line4"></div>
                        <br>
                        
                        <p style="    margin-top: 3%;">Call Us@ +91-8867700428, +91-8040964117</p>
                        <p>Mail Us@ support@xplotica.com</p>
                        <div class="mar-top-20"></div>
                        <br><br>
                        <h5><strong>For International Clients Assistance</strong></h5>
                        <p>Call Us@ +91-800-975-6189</p>
                        <p>Skype@ Xplotica</p>
                        <p>Mail Us@ support@xplotica.com</p>
                        <p>Website@ <a href="http://xplotica.com/" target="_blank">www.xplotica.com</a></p>
                    </div> 
                   
                </div>
            </div> 
        </div><!--# content part close #---> 
    </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="js/mdb.min.js"></script>
<?php include("footer.php"); ?>


