<?php
error_reporting(E_ALL);
if(isset($_POST['username']) && isset($_POST['email']) && isset($_POST['phonenumber']) && isset($_POST['subject']) && isset($_POST['message'])){
    $name=$_POST['username'];
    $email=$_POST['email'];
    $phone=$_POST['phonenumber'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];

    $toAdmin ='nayakakashjit@outlook.com';
    //$toAdmin ='rashmita.d@g2evolution.co.in';
    $subjectAdmin = "New Web Enquiry from Contact us page";
    $UserSubject = "Greetings from Xplotica";
    $UserEmail= $email;
    $UserMessage = "";
    $UserMessage ="<html><head></head><body>";
    $UserMessage.= "<img src='http://g2evolution.co.in/g2evolution.png' alt='' / style='padding-left:100px'></body></html>";
    $UserMessage .= "<div style='width:600px;height:400px;background:#f7f7f7;border: 2px solid #03A9F4;color: #333;padding: 31px;box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);'>";
    $UserMessage .= "<p style='text-transform: capitalize;font-weight:600'>Dear $name,</p>";
    $UserMessage .= "<p style='margin-top:15px;'><b>Thank You For Enquiring With Us!.</b> <p>";                 
    $UserMessage .="<p>Our Business Devlopment Team Will Reach To You Earliest For Detail Discussion, <p>";
    $UserMessage .="<p>And Will Share You Very Cost Effective Quotation For The Application Development.<p>";
    $UserMessage .= "<p style='padding-top:25px'><b><i>Thanks & Regards</b></i></p>";        
    $UserMessage .= "<p>G2Evolution Team</p>";
    $UserMessage .= "<p>Contact No - +91 9591898534</p>";
    $UserMessage .= "<img src='http://g2evolution.co.in/images/logo.jpg'>";

    $UserMessage .= "<p style='color:blue;margin-top:70px'> Note:This is a auto generated E-mail. please do not reply.<p>";
    $UserMessage .= "</div>";
    $body = "";

    $body.= '<p><b>Dear Team</b>,</p>';
    $body .= "<p style='margin: 25px 0px;'>A new Customer has made a request for a quotation. Please find below the details.<p>";

    $body.="<p style='font-weight: bold;font-size: 14px;color: #07688D;'>CUSTOMER DETAILS</p>";
    $body.="<table width='500' border='0' cellspacing='1' cellpadding='6' style='background: #f7f7f7;color:#000;margin: auto; margin-left:0px;border:1px solid green;padding: 10px 25px; margin-bottom:6%;height:250px;'>";


            $body.="<tr>";
            $body.="<td width='200'>Name</td>";
            $body.="<td> ". $name ."</td></tr>";			

            $body.="<tr>";
            $body.="<td width='200'>E-mail</td>";
            $body.="<td> ".  $email ."</td></tr>";


            $body.="<tr>";
            $body.="<td width='200'>Phone</td>";
            $body.="<td> ". $phone ."</td></tr>";


            $body.="<tr>";
            $body.="<td width='200'>Subject</td>";
            $body.="<td> ". $subject ."</td></tr>";

            $body.="<tr>";
            $body.="<td width='200'>Message</td>";
            $body.="<td> ". $message ."</td></tr>";


            $body.="</table>";

            $body .= "<p>Note : This is an auto generated E-mail. Please do not reply.</p> ";

            $body.="</div></body>";
            $body.="</html>";


    $form = "nayakakashjit@gmail.com";
    $Adminheaders = "MIME-Version: 1.0" . "\r\n";
    $Adminheaders .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    // Additional headers
    $Adminheaders .= "From: ".$form; 
    $Userheaders = "MIME-Version: 1.0" . "\r\n";
    $Userheaders .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    $Userheaders .= "From: ".$form;


    // Mail it
    $sendMailtoAdmin=mail($toAdmin, $subjectAdmin , $body , $Adminheaders );
    $sendMailtoUser=mail($UserEmail, $UserSubject , $UserMessage , $Userheaders);

    if($sendMailtoAdmin && $sendMailtoUser){
        echo "success";
    } else{
        echo "failure";
    }
} 
else {
	echo"error";
}

?>